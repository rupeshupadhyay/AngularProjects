﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ApplicationLayer.Dtos
{
    public class ExcelDataProcessDto
    {
        public string? EventID { get; set; }
        public string? UploadGuid { get; set; }
        public string? UserName { get; set; }
    }
}
