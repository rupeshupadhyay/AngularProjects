import { Component, Input, OnInit } from '@angular/core';
import { DownloadexcelService } from 'src/app/services/export/downloadexcel.service';

@Component({
  selector: 'app-downloadexcel',
  templateUrl: './downloadexcel.component.html'
})
export class DownloadexcelComponent implements OnInit {

  // Get Input from implemented component
  @Input() Id:string="objDownload";
  @Input() strDownloadcaption:string="Download";
  @Input() strExportFilePrefix:string="Test";
  @Input() strWorkSheetNm:string="Details";
  @Input() headers:any[]=[];
  @Input() lineItemDto:any;
  @Input() ShowHeaderStyle:boolean=true;

  constructor(private downloadexcelsvc:DownloadexcelService) { }

  ngOnInit(): void {
  }

  DownloadExcelReport()
  {
    // assign the input data setup in parent component 
    this.downloadexcelsvc.filenm=this.strExportFilePrefix;
    this.downloadexcelsvc.worksheetnm=this.strWorkSheetNm;
    this.downloadexcelsvc.headerdata= this.headers;
    this.downloadexcelsvc.showheaderestyleflg=this.ShowHeaderStyle;
    this.downloadexcelsvc.lineItemDto=this.lineItemDto;
    this.downloadexcelsvc.ExportExcel();
  }

}
