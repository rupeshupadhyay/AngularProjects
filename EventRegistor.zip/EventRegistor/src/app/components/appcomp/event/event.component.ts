import { Component, OnInit } from '@angular/core';
import { EventDto } from './event-dto';
import { EventService } from './event.service';
import { Router, ActivatedRoute, ParamMap } from '@angular/router';
import { FormGroup, FormBuilder, FormControl, Validators } from '@angular/forms';
import { threadId } from 'worker_threads';

@Component({
  selector: 'app-event',
  templateUrl: './event.component.html'
})
export class EventComponent implements OnInit {
  eventdtos:EventDto[]=[];
  objNewEvent:EventDto = new EventDto();

  //Excel Report Header
  exportHeaders:string[]=["Entity ID","Entity Name","Pan Card No","Job Work Order No","Event Date", 
  "Created By", "Created On", "Updated By", "Updated On"];
  //Excel Line Items
  exportLineItems:any[]=[];
  
  //Screen Title
  title:string="Events";

  //Screen Captions
  captions:any[]=["Create Event","Entity Name","Pan Card No","Job Work Order No","Event Date","Actions"];

  constructor(private eventsvc:EventService,private route:ActivatedRoute,private router:Router) { }

  ngOnInit(): void {this.LoadEventData();}

  convertDtoinArray(objinput:any):any
  {
    var objOutPut=[];
    for(var i=0;i<objinput.length;i++)
    {
      const ele=objinput[i];
      objOutPut.push(Object.values(ele));
      this.exportLineItems.push(Object.values(ele));
      console.log(Object.values(ele));
      console.log(this.exportLineItems.push);
    }
    console.log(objOutPut);
    return objOutPut;
  }
  
  LoadEventData()
  {
     //Implementing Subscriber
     this.eventsvc.getEventList().subscribe(
      (response: EventDto[]) => {
        this.eventdtos = response;
        console.log(this.eventdtos);
        //Coverting Event Json in Array of Array
        this.exportLineItems=this.convertDtoinArray(this.eventdtos);
      }
    );
  }

  DeleteEventData(objEventID:string)
  {
      this.eventsvc.deleteEventdata(objEventID).subscribe(
        (response?: any) => 
        {
            //Add Project to Grid
          console.log(response);
          this.router.navigateByUrl('\events', {
            replaceUrl: true
          });
        },
        (error: any) => 
        {
          console.log(error); 
          //this.router.navigate(['events']); 
        },
        ()=>{console.log('Data Update Completed.')}
      );
    }

    GotoCreateEvent()
    {
      this.router.navigate(['createE']);
    }
  
    onEditClick(event: any, eventid: number)
    {
      //Get Selected Values and Move to Edit 
      sessionStorage['app.eventid']= eventid;
      this.router.navigateByUrl('editE');

    }

    onDeleteClick(event: any, eventid: number)
    {
      console.log(`Delete Calling Event ID::- ${eventid}`)
      
      console.log(eventid);
      if(confirm(`Are you sure to delete Event ID:${eventid}`)==true)
      {
        this.DeleteEventData(eventid.toString());
        this.LoadEventData();
      }

    }
}
