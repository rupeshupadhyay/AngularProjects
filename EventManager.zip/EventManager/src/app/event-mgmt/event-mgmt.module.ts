import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { EventManagerComponent } from './event-manager/event-manager.component';
import { EventComponent } from './event/event.component';
import { EventSvcService } from './event-svc.service';
import { FormsModule,ReactiveFormsModule } from '@angular/forms';

@NgModule({
  declarations: [
    EventManagerComponent,
    EventComponent
  ],
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule
  ],
  providers:[
    EventSvcService
  ],
  exports:[
    EventManagerComponent,
    EventComponent
  ]
})
export class EventMgmtModule { }
