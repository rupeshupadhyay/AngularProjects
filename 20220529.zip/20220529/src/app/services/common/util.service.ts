import { Injectable } from '@angular/core';

@Injectable({providedIn: 'root'})

export class UtilService 
{

  constructor() { }

  convertDtoinArray(objinput:any):any
  {
    var objOutPut=[];
    for(var i=0;i<objinput.length;i++)
    {
      const ele=objinput[i];
      objOutPut.push(Object.values(ele));
    }
    return objOutPut;
  }
}
