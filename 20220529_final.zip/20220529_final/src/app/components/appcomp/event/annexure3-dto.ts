export class Annexure3Dto 
{
    dp_id:string;
    holder_folio:string;
    dp_id_n_holder_folio:string;
    pan:string;

    constructor()
    {
        this.dp_id='';
        this.holder_folio='';
        this.dp_id_n_holder_folio='';
        this.pan='';
    }
}
