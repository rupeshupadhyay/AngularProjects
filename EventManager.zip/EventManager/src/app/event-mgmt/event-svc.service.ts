import { Injectable } from '@angular/core'; // Service
import {HttpClient} from '@angular/common/http'; // Http Client 
import { Observable } from 'rxjs'; // Subscription Metod 
import {EventDto} from './event-dto'; // Model Class Dto for Data Transfer Activities. 

@Injectable()
export class EventSvcService {
  urlPrefix: string = "http://localhost:5000";
  //HttpClient Injection
  constructor(private httpclient:HttpClient) { }
  //Observable for registering API Service
  getEventList(): Observable<EventDto[]>
  {
    //Get Command
    return this.httpclient.get<EventDto[]>("http://localhost:5148/api/Event");
  }

  postEventdata(project:EventDto): Observable<EventDto>
  {
    //Post Command
    return this.httpclient.post<EventDto>("http://localhost:5148/api/Event",EventDto);
  }
}
