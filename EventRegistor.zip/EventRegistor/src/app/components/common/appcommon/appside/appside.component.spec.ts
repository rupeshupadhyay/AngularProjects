import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AppsideComponent } from './appside.component';

describe('AppsideComponent', () => {
  let component: AppsideComponent;
  let fixture: ComponentFixture<AppsideComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AppsideComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AppsideComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
