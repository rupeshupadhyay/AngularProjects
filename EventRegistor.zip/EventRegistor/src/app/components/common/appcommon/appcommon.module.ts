import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AppheaderComponent } from './appheader/appheader.component';
import { AppfooterComponent } from './appfooter/appfooter.component';
import { AppsideComponent } from './appside/appside.component';
import { DownloadexcelComponent } from './downloadexcel/downloadexcel.component';
import { DownloadexcelService } from 'src/app/services/export/downloadexcel.service';
import { UploadexcelComponent } from './uploadexcel/uploadexcel.component';

@NgModule({
  declarations: [
    AppheaderComponent,
    AppfooterComponent,
    AppsideComponent,
    DownloadexcelComponent,
    UploadexcelComponent
  ],
  providers:[
    DownloadexcelService
  ],
  imports: [
    CommonModule
  ],
  exports: [
    AppheaderComponent,
    AppfooterComponent,
    DownloadexcelComponent,
    UploadexcelComponent
  ]
})
export class AppcommonModule { }
