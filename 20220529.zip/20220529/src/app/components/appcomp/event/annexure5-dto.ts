export class Annexure5Dto 
{
    pan:string;
    status:string;
    name:string;
    created_date:string;

    constructor()
    {
        this.pan='';
        this.status='';
        this.name='';
        this.created_date='';
    }
}
