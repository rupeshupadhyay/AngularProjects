import { Component, NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AppcompModule } from './components/appcomp/appcomp.module';
import { EventCreateComponent } from './components/appcomp/event/event-create/event-create.component';
import { EventEditComponent } from './components/appcomp/event/event-edit/event-edit.component';
import { EventUploadComponent } from './components/appcomp/event/event-upload/event-upload.component';
import {EventComponent} from './components/appcomp/event/event.component'; 

const routes: Routes = [
  { path:'events', component:EventComponent},
  {path:'editE', component:EventEditComponent},
  {path:'createE', component:EventCreateComponent},
  {path:'uploadE', component:EventUploadComponent},
  { path: '', redirectTo: 'events', pathMatch: 'full' },
];

@NgModule({
  imports: [RouterModule.forRoot(routes),
  AppcompModule
  ],
  exports: [RouterModule]
})
export class AppRoutingModule { }
