import { Component, Input, OnInit} from '@angular/core';
import {HttpClient, HttpEvent, HttpEventType, HttpErrorResponse} from '@angular/common/http';
import {catchError, Observable, of, retry, throwError} from 'rxjs';
import { EventService } from 'src/app/components/appcomp/event/event.service';
import { ExcelDataProcessDto } from 'src/app/components/appcomp/event/excel-data-process-dto';

@Component({
  selector: 'app-uploadexcel',
  templateUrl: './uploadexcel.component.html'
})

export class UploadexcelComponent implements OnInit {

  @Input() ID:string="objUpload"; 
  @Input() UploadCaption:string="Demo";
  @Input() ProcessId:string="0";
  @Input() CustomField:string="";

  fileExtension: any = "";
  validfilextensions: string[] = [];
  validextensionflg: boolean = false;
  apiUrl: string = "http://localhost:5148/api/ExcelDataProcess/Upload";
  message:string="";
  apiResponse:string="";
  exceldataprocessdto:ExcelDataProcessDto = new ExcelDataProcessDto();

  // Adding Dependencies of HttpClient 
  constructor(private http: HttpClient,private eventsvc:EventService) { }

  ngOnInit(): void {}

  validatefilextension() 
  {
    // If extension found in list
    let found = this.validfilextensions.find((i) => i === this.fileExtension);
    if (found != undefined) { found.length > 0 ? this.validextensionflg = true : this.validextensionflg = false; }
  }

  uploaddata(files: any)  
  {
    console.log('uploaddata :'+'Upload proces started.');

    if (files.length===0) 
    { 
      console.log('No File Selected.');
      return ; 
    }
      
    let fileToUpload = <File>files[0];
    let formData = new FormData();  
    formData.append('file',fileToUpload,fileToUpload.name);
    
    console.log('uploaddata :'+'API Call Inititated')
    
    return this.http.post(this.apiUrl + '/' + this.ProcessId, formData,{reportProgress:true,responseType:"text"})
            .subscribe(
            {
              next:(res:any)=>
              {
                console.log('uploaddata (Next) :'+'Event Calling('+res+')');
                this.getEventMessage(res, fileToUpload)   
                // Get the Guid and Call the Data Process API to Process Temp Data        
                this.exceldataprocessdto.eventID= this.CustomField;
                this.exceldataprocessdto.uploadGuid=res;
                this.exceldataprocessdto.userName = "DEMOUSER";
                
                this.eventsvc.postExceldata(this.exceldataprocessdto).subscribe
                (
                  (response?: string) => 
                  {
                    //Add Project to Grid
                    //this.router.navigateByUrl('\events');
                  },
                  (error:any) => 
                  {console.log(error);}
                );
              },
              error:(err:HttpErrorResponse)=>
              {
                console.log(err.error);
              },
              complete:()=>
              {
                console.log('uploaddata (Complete) :'+'File Upload process completed.');
                this.message='';
              }
            }
          )
  }

  getEventMessage(event: HttpEvent<any>, file: File): any 
  {
    switch (event.type) 
    {
      case HttpEventType.Sent:
        console.log(event.type); 
        this.message = `Uploading file "${file.name}" of size ${file.size}.`;
        console.log('Event Sent :'+this.message);
        return this.message;
      case HttpEventType.UploadProgress:// Compute and show the % done:
        console.log(event.type);
        const percentDone = Math.round(100 * event.loaded / (event.total ?? 0));
        this.message= `File "${file.name}" is ${percentDone}% uploaded.`;
        console.log('Event Upload Progress :'+this.message);
        return this.message;
      case HttpEventType.Response:
        console.log(event.type);
        this.message= `File "${file.name}" was completely uploaded!`;
        console.log('Event Response :'+this.message);
        console.log('Event Body :'+ event.body);
        return this.message;
      default: 
        this.message= `File "${file.name}" surprising upload event.`;
        return this.message;
    }
  }

  handleError(file: any) 
  {
    const userMessage = `${file.name} upload failed.`;
    return (error: HttpErrorResponse) => 
        {
          console.error(error); // log to console instead
          const message = (error.error instanceof Error) ?
          error.error.message : `server returned code ${error.status} with body "${error.error}"`;
          console.log(`${userMessage} ${message}`);

          // Let app keep running but indicate failure.
          return of(userMessage);
      }
  }
}
