import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-appside',
  templateUrl: './appside.component.html',
  styleUrls: ['./appside.component.scss']
})
export class AppsideComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
