﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using ApplicationLayer.Repositories;
using ApplicationLayer.Models;
using System.Net;
using ApplicationLayer.Dtos;

namespace EventDataAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class EventController : ControllerBase
    {
        private readonly IEventRepository _eventRepository;
        private readonly ILogger<EventController> _logger;
        private readonly IConfiguration _configuration;

        public EventController(IEventRepository eventRepository, ILogger<EventController> logger, IConfiguration configuration)
        {
            _eventRepository = eventRepository ?? throw new ArgumentNullException(nameof(eventRepository));
            _configuration = configuration ?? throw new ArgumentNullException(nameof(configuration));
            
            _logger = logger ?? throw new ArgumentNullException(nameof(logger));
        }

        [HttpGet]
        [ProducesResponseType(typeof(IEnumerable<EventDto>), (int) HttpStatusCode.OK)]
        public async Task<ActionResult<IEnumerable<EventDto>>> GetEvent()
        {
            try
            {
                _eventRepository.DbConnectionString =_configuration.GetValue<string>("DatabaseSettings:ConnectionStrings");
                return Ok(await _eventRepository.GetAllEvents());
             }
            catch (Exception ex)
            {
                return Problem(ex.Message);
            }
        }

        [HttpGet("{id}/DupPan", Name = "GetDupPan")]
        [ProducesResponseType(typeof(IEnumerable<Annxure2>), (int)HttpStatusCode.OK)]
        public async Task<ActionResult<IEnumerable<Annxure2>>> GetDupPan(int id)
        {
            try
            {
                return Ok(await _eventRepository.GetAnnxure2(id));
            }
            catch (Exception ex)
            {
                return Problem(ex.Message);
            }
        }

        [HttpGet("{id}", Name = "GetEvent")]
        [ProducesResponseType((int)HttpStatusCode.NotFound)]
        [ProducesResponseType((int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(Event), (int)HttpStatusCode.OK)]
        public async Task<ActionResult<EventDto>> GetEventById(int id)
        {
            try
            {
                _eventRepository.DbConnectionString = _configuration.GetValue<string>("DatabaseSettings:ConnectionStrings");
                var results = await _eventRepository.GetEvent(id);
                if (results == null) return NotFound();
                return Ok(results);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [HttpPost]
        [Consumes("application/json")]
        public async Task<IActionResult> AddNewEvent([FromBody] EventDto ev)
        {
            try
            {
                await _eventRepository.AddNewEvent(ev);
                return Ok();
            }
            catch (Exception ex)
            {
                return Problem(ex.Message);
            }
        }

        [HttpPut]
        [Consumes("application/json")]
        public async Task<IActionResult> UpdateEvent(EventDto ev)
        {
            try
            {
                await _eventRepository.UpdateEvent(ev);
                return Ok();
            }
            catch (Exception ex)
            {
                return Problem(ex.Message);
            }
        }

        [HttpDelete("{id}")]
        [HttpDelete]
        public async Task<IActionResult> DeleteEvent(int id)
        {
            try
            {
                await _eventRepository.DeleteEvent(id);
                return Ok();
            }
            catch (Exception ex)
            {
                return Problem(ex.Message);
            }
        }

    }
}
