﻿using System.Data;

namespace SQLDataAccess
{
    public interface ISqlDataHelper
    {
        public string? DbConnectionString { get; set; }

        Task<IEnumerable<T>> GetData<T, U>(string storedProcedure, U parameters, string connectionId = "Default");
        Task SaveData<T>(string storedProcedure, T parameters, string connectionId = "Default");

        Task<bool> ProcessDataAdotoSQL(DataSet srcDataSet, List<string> dbDestTableList, bool blncolumnMappingActionSts = false,
            string? processname = "", string? processfield1 = "", string? processfield2 = "", string? processfield3 = "",
            string? processfield4 = "", string? processfield5 = "", string? processfield6 = "", string? processfield7 = "",
            string? processfield8 = "", string? processfield9 = "", string? processfield10 = "");
    }
}