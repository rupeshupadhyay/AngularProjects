﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ApplicationLayer.Dtos
{
    public class Annexure5Dto
    {
        public string? Pan { get; }
        public string? Status { get; }
        public string? Name { get; }
        public string? Created_date { get; }

    }
}
