﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ApplicationLayer.Dtos
{
    public class Annexure8Dto
    {
        public string? Bfitpan { get; }
        public string? Dpid { get; }
        public string? Holder_folio { get; }
        public string? Holder { get; }
        public string? Second { get; }
        public string? Third { get; }
        public string? Holder_addr1 { get; }
        public string? Holder_addr2 { get; }
        public string? Holder_addr3 { get; }
        public string? Holder_addr4 { get; }
        public string? Holder_pin { get; }
        public string? Bank_accno { get; }
        public string? Bank_name { get; }
        public string? Bank_addr1 { get; }
        public string? Bank_addr2 { get; }
        public string? Bank_addr3 { get; }
        public string? Bank_addr4 { get; }
        public string? Bank_pin { get; }
        public string? Ifsc_code { get; }
        public string? Ecs_micr { get; }
        public string? Ecs_actype { get; }
        public string? Ecs_acno { get; }
        public string? Bfitpan2 { get; }
        public string? Isin_code { get; }
        public string? Hold_minor { get; }
        public string? Status_desc { get; }
        public string? Pul_code { get; }
        public string? Total_shar { get; }
        public string? Gross_amt { get; }
        public string? Tdsamt { get; }
        public string? Net_amount { get; }
        public string? Tax_per { get; }
        public string? Country_code { get; }
        public string? Country_name { get; }
        public string? Bank { get; }
        public string? War_mode { get; }
        public string? Warrantno { get; }
        public string? Type { get; }
        public string? Benpos_date { get; }
        public string? Wardate { get; }
        public string? War_acno { get; }
        public string? Old_gross { get; }
        public string? Old_tds { get; }
        public string? Currentdividend { get; }
        public string? Olddividend { get; }
        public string? Total_dividend_paid { get; }
        public string? Residential_status { get; }
        public string? Pan_verification { get; }
        public string? Specified_person_sec_206ab { get; }
        public string? Shareholder_category { get; }
        public string? Threshhold_benefit_allowed { get; }
        public string? Accept_reject { get; }
        public string? Reasons { get; }
        public string? Tds_rate { get; }
        public string? Base_tds_rate { get; }
        public string? Surcharge { get; }
        public string? Education_cess { get; }
        public string? Effective_tds_rate { get; }
        public string? Tds_amount { get; }
        public string? Net_amount1 { get; }
        public string? Form_15ca_cb_compliance { get; }

    }
}
