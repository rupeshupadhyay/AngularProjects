import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http';
import { Observable } from 'rxjs';
import {Project} from './project';

//Project Service
@Injectable({
  providedIn: 'root'
})
export class ProjectsService {

  urlPrefix: string = "http://localhost:5000";
  //HttpClient Injection
  constructor(private httpclient:HttpClient) { }
  //Observable for registering API Service
  getProjectList(): Observable<Project[]>
  {
    //Get Command
    return this.httpclient.get<Project[]>("http://localhost:5000/api/Projects");
  }

  postProjectdata(project:Project): Observable<Project>
  {
    //Post Command
    return this.httpclient.post<Project>("http://localhost:5000/api/Projects",project);
  }

 
}
