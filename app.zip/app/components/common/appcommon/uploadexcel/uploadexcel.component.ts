import { Component, Input, OnInit} from '@angular/core';
import {HttpClient, HttpEvent, HttpEventType, HttpErrorResponse} from '@angular/common/http';
import {of} from 'rxjs';

@Component({
  selector: 'app-uploadexcel',
  templateUrl: './uploadexcel.component.html'
})

export class UploadexcelComponent implements OnInit {

  @Input() UploadCaption:string="Demo";
  @Input() tableId:string="0";

  fileExtension: any = "";
  validfilextensions: string[] = [];
  validextensionflg: boolean = false;
  apiUrl: string = "http://localhost:5148/api/ExcelDataProcess/Upload";
  message:string="";

  // Adding Dependencies of HttpClient 
  constructor(private http: HttpClient) { }

  ngOnInit(): void {}

  validatefilextension() 
  {
    // If extension found in list
    let found = this.validfilextensions.find((i) => i === this.fileExtension);
    if (found != undefined) { found.length > 0 ? this.validextensionflg = true : this.validextensionflg = false; }
  }

  uploaddata(files: any) 
  {
    console.log('uploaddata :'+'Upload proces started')
    if (files.length===0) { 
      console.log('No File Selected.')
      return; }
      
    let fileToUpload = <File>files[0];

    let formData = new FormData();  
    formData.append('file',fileToUpload,fileToUpload.name);
    
    console.log('uploaddata :'+'API Call Inititated')
    
    this.http.post(this.apiUrl + '/' + this.tableId, formData,{reportProgress:true, observe: 'events'})
    .subscribe(
      {
        next:(event:any)=>{
          console.log('uploaddata (Next) :'+'Event Calling');
          this.getEventMessage(event, fileToUpload)
        },
        error:(error:any)=>{
          console.log('uploaddata (Error) :'+'Eror in File Upload process.')
          this.handleError(fileToUpload)},
        complete:()=>{
          console.log('uploaddata (Complete) :'+'File Upload process completed.');
          this.message='';
        }
      }
    )
  }

  handleError(file: any) 
  {
    const userMessage = `${file.name} upload failed.`;
    return (error: HttpErrorResponse) => 
        {
          console.error(error); // log to console instead
          const message = (error.error instanceof Error) ?
          error.error.message : `server returned code ${error.status} with body "${error.error}"`;
          console.log(`${userMessage} ${message}`);

          // Let app keep running but indicate failure.
          return of(userMessage);
      }
  }

  getEventMessage(event: HttpEvent<any>, file: File): any 
  {
    switch (event.type) {
      case HttpEventType.Sent: 
        this.message = `Uploading file "${file.name}" of size ${file.size}.`;
        console.log('Event Sent :'+this.message);
        return this.message;
      case HttpEventType.UploadProgress:// Compute and show the % done:
        const percentDone = Math.round(100 * event.loaded / (event.total ?? 0));
        this.message= `File "${file.name}" is ${percentDone}% uploaded.`;
        console.log('Event Upload Progress :'+this.message);
        return this.message;
      case HttpEventType.Response:
        this.message= `File "${file.name}" was completely uploaded!`;
        console.log('Event Response :'+this.message);
        return this.message;
      default: 
      this.message= `File "${file.name}" surprising upload event: ${event.type}.`;
      return this.message;
    }
  }
}
