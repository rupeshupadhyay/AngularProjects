import { Component, OnInit } from '@angular/core';
import { EventDto } from '../event-dto';
import { EventService } from '../event.service';
import { Router, ActivatedRoute} from '@angular/router';
import { FormGroup, FormBuilder, FormControl, Validators } from '@angular/forms';


@Component({
  selector: 'app-event-edit',
  templateUrl: './event-edit.component.html'
})
export class EventEditComponent implements OnInit {
  eventID: string = "";
  entityName: string = "";
  panCardNum: string = "";
  jobWorkOrderNum: string = "";
  eventDate: string = "";

  eventdtos: EventDto[] = [];
  objEditEvent: EventDto = new EventDto();

  constructor(private eventsvc: EventService, private route: ActivatedRoute, private router: Router) {
    this.objEditEvent.entityName = "";
    this.objEditEvent.panCardNum = "";
    this.objEditEvent.jobWorkOrderNum = "";
    this.objEditEvent.eventDate = "";
    this.objEditEvent.createdBy = "";
    this.objEditEvent.eventID = 0;
    this.objEditEvent.lastModifiedBy = "";
    this.objEditEvent.lastModifiedDate = "";
  }

  ngOnInit(): void 
  {
    this.eventID = sessionStorage['app.eventid'];
    sessionStorage.removeItem('app.eventid');
    
    console.log(this.eventID);
    this.eventsvc.getEventListID(this.eventID.toString()).subscribe(
      (response: EventDto) => 
      {
        this.objEditEvent = response;
      },
      (error:any)=>{console.log(error)},
      ()=>{this.LoadEventData();}
    );
  }

  LoadEventData() {
    console.log('Edited Event ID : ' + this.eventID.toString())
    let str = this.objEditEvent.eventDate;
    let date = new Date(str + "Z");
    this.objEditEvent.eventDate = date.toString();
    console.log(this.objEditEvent.eventDate);
    console.log(this.eventdtos);
  }

  onSaveClick() 
  {
    console.log(this.objEditEvent);

    this.eventsvc.putEventdata(this.objEditEvent).subscribe(
        (response?: EventDto) => 
        {
          //Add Project to Grid
          console.log(response);
          // After updating data move to event list page
          this.router.navigateByUrl('\events', {replaceUrl: true});
        },
        (error: any) => {console.log(error);},
        ()=>{console.log('Data Update Completed.')}
    );
  }

  onUploadClick() 
  {
    sessionStorage['app.eventid']=this.eventID;
    sessionStorage['app.entitynm']=this.objEditEvent.entityName;
    sessionStorage['app.eventdate']=this.objEditEvent.eventDate;
    this.router.navigateByUrl('/uploadE', {replaceUrl: true});
  }

  onCancelClick()
  {
    this.router.navigateByUrl('\events', {replaceUrl: true});
  }


}
