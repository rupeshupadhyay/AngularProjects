import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-appheader',
  templateUrl: './appheader.component.html'
})
export class AppheaderComponent implements OnInit {

  title:string='Event Registor';
  
  headerroutes= [
    {"link":"events","title":"Event"},
    {"link":"about","title":"About"},
  ];

  constructor() { }

  ngOnInit(): void {
  }

}
