﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ApplicationLayer.Models;

namespace ApplicationLayer.Common
{
    public class UploadParameterDetails
    {
        public static List<UploadParams> GetUploadParms()
        {
            return new List<UploadParams>
            {
                new UploadParams {ProcessName="Annexure1",ProcessField1="",ProcessField2="TBL_GENERIC_UPLOAD",ProcessField3="DIVIDEND_REGISTER_ANEX_1_STAGE1",ProcessField4="",ProcessField5="",
                    ProcessField6="",ProcessField7="",ProcessField8="",ProcessField9="",ProcessField10=""},
                new UploadParams {ProcessName="Annexure3",ProcessField1="",ProcessField2="TBL_GENERIC_UPLOAD",ProcessField3="PAN_NOT_TO_CONSIDER_ANEX_3",ProcessField4="",ProcessField5="",
                    ProcessField6="",ProcessField7="",ProcessField8="",ProcessField9="",ProcessField10=""},
                new UploadParams {ProcessName="Annexure5",ProcessField1="",ProcessField2="TBL_GENERIC_UPLOAD",ProcessField3="PAN_VERIFICATION_ANEX_5",ProcessField4="",ProcessField5="",
                    ProcessField6="",ProcessField7="",ProcessField8="",ProcessField9="",ProcessField10=""},
                new UploadParams {ProcessName="Annexure6",ProcessField1="",ProcessField2="TBL_GENERIC_UPLOAD",ProcessField3="SECTION_206AB_ANEX_6",ProcessField4="",ProcessField5="",
                    ProcessField6="",ProcessField7="",ProcessField8="",ProcessField9="",ProcessField10=""},
                new UploadParams {ProcessName="Annexure7",ProcessField1="",ProcessField2="TBL_GENERIC_UPLOAD",ProcessField3="SHAREHOLDER_DECLARATION_ANEX_7",ProcessField4="",ProcessField5="",
                    ProcessField6="",ProcessField7="",ProcessField8="",ProcessField9="",ProcessField10=""},
                new UploadParams {ProcessName="Annexure14",ProcessField1="",ProcessField2="TBL_GENERIC_UPLOAD",ProcessField3="INDIVIDUAL_CATEGORY_MASTER",ProcessField4="",ProcessField5="",
                    ProcessField6="",ProcessField7="",ProcessField8="",ProcessField9="",ProcessField10=""},
                new UploadParams {ProcessName="Annexure13",ProcessField1="",ProcessField2="TBL_GENERIC_UPLOAD",ProcessField3="DIVIDEND_IEPF_REGISTER_ANNEX14_STAGE1",ProcessField4="",ProcessField5="",
                    ProcessField6="",ProcessField7="",ProcessField8="",ProcessField9="",ProcessField10=""}
            };
        }
    }
}

