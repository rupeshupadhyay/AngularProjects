import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, FormControl, Validators } from '@angular/forms';
import { HttpClient } from '@angular/common/http';
import { DATE_PIPE_DEFAULT_TIMEZONE } from '@angular/common';
import { Router, ActivatedRoute, ParamMap } from '@angular/router';
import { Observable } from 'rxjs';

@Component({
  selector: 'app-event-manager',
  templateUrl: './event-manager.component.html',
  styleUrls: ['./event-manager.component.scss']
})

export class EventManagerComponent implements OnInit {
  apiUrl:string='http://localhost:5000/api/ExcelDataProcess/UploadExcelData';
  fileSrc:string='';
  currentDate:string;
  myForm= new FormGroup(
    {
      file:new FormControl('',[Validators.required,]),
      fileSource:new FormControl('',[Validators.required])
    }
  )

  
  constructor( private http: HttpClient,private route: ActivatedRoute) { 
    this.currentDate= Date();

  }

  get f(){
    return this.myForm.controls;
  }

  
  onFileChange(event:any)
  {
    if (event.target.files && event.target.files.length)
    {
      const [file]=event.target.files;
    }
  }

  submitstep1()
  {
    /*console.log(this.myForm.value);
    this.http.post<any>(this.apiUrl, this.myForm.value).subscribe(response => {
      console.log(response);
      alert('Uploaded Sucessfully.')
    }, error => {
      console.log(error);
    });*/
    /*this.http.post(apiUrl,this.myForm.value)
    .subscribe(
      res=>{
        console.log(res);
        alert('Uploaded Sucessfully.')
      }
    )*/

  }

  ngOnInit(): void {
    const heroId = this.route.snapshot.paramMap.get('entityName');
    console.log(heroId);
    
  }

}
