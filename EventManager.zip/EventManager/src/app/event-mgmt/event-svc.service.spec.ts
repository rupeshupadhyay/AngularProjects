import { TestBed } from '@angular/core/testing';

import { EventSvcService } from './event-svc.service';

describe('EventSvcService', () => {
  let service: EventSvcService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(EventSvcService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
