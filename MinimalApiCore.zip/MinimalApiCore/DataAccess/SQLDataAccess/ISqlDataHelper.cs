﻿
using System.Data;

namespace SQLDataAccess
{
    public interface ISqlDataHelper
    {
        Task<IEnumerable<T>> GetData<T, U>(string storedProcedure, U parameters, string connectionId = "Default");
        Task SaveData<T>(string storedProcedure, T parameters, string connectionId = "Default");

        Task<bool> ProcessDataAdotoSQL(DataSet srcDataSet, string dbDestinationTblNm, List<string> dbDestTableList, bool blncolumnMappingActionSts = true);
    }
}