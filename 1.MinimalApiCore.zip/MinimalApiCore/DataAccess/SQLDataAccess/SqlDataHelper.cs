﻿using Dapper;
using Microsoft.Extensions.Configuration;
using System.Data;
using System.Data.SqlClient;

namespace SQLDataAccess
{
    public class SqlDataHelper : ISqlDataHelper
    {
        public string? DbConnectionString { get; set; }

        public SqlDataHelper()
        {
            DbConnectionString = "Data Source =.; Initial Catalog = EventDB; User ID = scott; pwd = tiger; ";
        }

        public async Task<IEnumerable<T>> GetData<T, U>(
            string storedProcedure,
            U parameters,
            string connectionId = "Default")
        {
            using IDbConnection connection = new SqlConnection(DbConnectionString);

            return await connection.QueryAsync<T>(storedProcedure, parameters,
                commandType: CommandType.StoredProcedure);
        }

        public async Task SaveData<T>(
            string storedProcedure,
            T parameters,
            string connectionId = "Default")
        {
            using IDbConnection connection = new SqlConnection(DbConnectionString);

            await connection.ExecuteAsync(storedProcedure, parameters,
                commandType: CommandType.StoredProcedure);
        }

        public DataTable ProcessGenericAdoDataset(DataTable dtInputData,string processname="",string processfield1="",string processfield2="", 
            string processfield3="", string processfield4="",string processfield5="", string processfield6="", string processfield7="", 
            string processfield8="", string processfield9="", string processfield10="")
        {
            DataTable? dtOutputData=null;
            Int32? inputtablecolcount = null;

            try
            {
                inputtablecolcount = dtInputData.Columns.Count;
                dtOutputData = new DataTable();
                dtOutputData.Columns.Add("PROCESSNAME", typeof(string));
                dtOutputData.Columns.Add("PROCESSFIELD1", typeof(string));
                dtOutputData.Columns.Add("PROCESSFIELD2", typeof(string));
                dtOutputData.Columns.Add("PROCESSFIELD3", typeof(string));
                dtOutputData.Columns.Add("PROCESSFIELD4", typeof(string));
                dtOutputData.Columns.Add("PROCESSFIELD5", typeof(string));
                dtOutputData.Columns.Add("PROCESSFIELD6", typeof(string));
                dtOutputData.Columns.Add("PROCESSFIELD7", typeof(string));
                dtOutputData.Columns.Add("PROCESSFIELD8", typeof(string));
                dtOutputData.Columns.Add("PROCESSFIELD9", typeof(string));
                dtOutputData.Columns.Add("PROCESSFIELD10", typeof(string));
                dtOutputData.Columns.Add("CUSTOMFIELD1", typeof(string));
                dtOutputData.Columns.Add("CUSTOMFIELD2", typeof(string));
                dtOutputData.Columns.Add("CUSTOMFIELD3", typeof(string));
                dtOutputData.Columns.Add("CUSTOMFIELD4", typeof(string));
                dtOutputData.Columns.Add("CUSTOMFIELD5", typeof(string));
                dtOutputData.Columns.Add("CUSTOMFIELD6", typeof(string));
                dtOutputData.Columns.Add("CUSTOMFIELD7", typeof(string));
                dtOutputData.Columns.Add("CUSTOMFIELD8", typeof(string));
                dtOutputData.Columns.Add("CUSTOMFIELD9", typeof(string));
                dtOutputData.Columns.Add("CUSTOMFIELD10", typeof(string));
                dtOutputData.Columns.Add("CUSTOMFIELD11", typeof(string));
                dtOutputData.Columns.Add("CUSTOMFIELD12", typeof(string));
                dtOutputData.Columns.Add("CUSTOMFIELD13", typeof(string));
                dtOutputData.Columns.Add("CUSTOMFIELD14", typeof(string));
                dtOutputData.Columns.Add("CUSTOMFIELD15", typeof(string));
                dtOutputData.Columns.Add("CUSTOMFIELD16", typeof(string));
                dtOutputData.Columns.Add("CUSTOMFIELD17", typeof(string));
                dtOutputData.Columns.Add("CUSTOMFIELD18", typeof(string));
                dtOutputData.Columns.Add("CUSTOMFIELD19", typeof(string));
                dtOutputData.Columns.Add("CUSTOMFIELD20", typeof(string));
                dtOutputData.Columns.Add("CUSTOMFIELD21", typeof(string));
                dtOutputData.Columns.Add("CUSTOMFIELD22", typeof(string));
                dtOutputData.Columns.Add("CUSTOMFIELD23", typeof(string));
                dtOutputData.Columns.Add("CUSTOMFIELD24", typeof(string));
                dtOutputData.Columns.Add("CUSTOMFIELD25", typeof(string));
                dtOutputData.Columns.Add("CUSTOMFIELD26", typeof(string));
                dtOutputData.Columns.Add("CUSTOMFIELD27", typeof(string));
                dtOutputData.Columns.Add("CUSTOMFIELD28", typeof(string));
                dtOutputData.Columns.Add("CUSTOMFIELD29", typeof(string));
                dtOutputData.Columns.Add("CUSTOMFIELD30", typeof(string));
                dtOutputData.Columns.Add("CUSTOMFIELD31", typeof(string));
                dtOutputData.Columns.Add("CUSTOMFIELD32", typeof(string));
                dtOutputData.Columns.Add("CUSTOMFIELD33", typeof(string));
                dtOutputData.Columns.Add("CUSTOMFIELD34", typeof(string));
                dtOutputData.Columns.Add("CUSTOMFIELD35", typeof(string));
                dtOutputData.Columns.Add("CUSTOMFIELD36", typeof(string));
                dtOutputData.Columns.Add("CUSTOMFIELD37", typeof(string));
                dtOutputData.Columns.Add("CUSTOMFIELD38", typeof(string));
                dtOutputData.Columns.Add("CUSTOMFIELD39", typeof(string));
                dtOutputData.Columns.Add("CUSTOMFIELD40", typeof(string));
                dtOutputData.Columns.Add("CUSTOMFIELD41", typeof(string));
                dtOutputData.Columns.Add("CUSTOMFIELD42", typeof(string));
                dtOutputData.Columns.Add("CUSTOMFIELD43", typeof(string));
                dtOutputData.Columns.Add("CUSTOMFIELD44", typeof(string));
                dtOutputData.Columns.Add("CUSTOMFIELD45", typeof(string));
                dtOutputData.Columns.Add("CUSTOMFIELD46", typeof(string));
                dtOutputData.Columns.Add("CUSTOMFIELD47", typeof(string));
                dtOutputData.Columns.Add("CUSTOMFIELD48", typeof(string));
                dtOutputData.Columns.Add("CUSTOMFIELD49", typeof(string));
                dtOutputData.Columns.Add("CUSTOMFIELD50", typeof(string));
                dtOutputData.Columns.Add("CUSTOMFIELD51", typeof(string));
                dtOutputData.Columns.Add("CUSTOMFIELD52", typeof(string));
                dtOutputData.Columns.Add("CUSTOMFIELD53", typeof(string));
                dtOutputData.Columns.Add("CUSTOMFIELD54", typeof(string));
                dtOutputData.Columns.Add("CUSTOMFIELD55", typeof(string));
                dtOutputData.Columns.Add("CUSTOMFIELD56", typeof(string));
                dtOutputData.Columns.Add("CUSTOMFIELD57", typeof(string));
                dtOutputData.Columns.Add("CUSTOMFIELD58", typeof(string));
                dtOutputData.Columns.Add("CUSTOMFIELD59", typeof(string));
                dtOutputData.Columns.Add("CUSTOMFIELD60", typeof(string));
                dtOutputData.Columns.Add("CUSTOMFIELD61", typeof(string));
                dtOutputData.Columns.Add("CUSTOMFIELD62", typeof(string));
                dtOutputData.Columns.Add("CUSTOMFIELD63", typeof(string));
                dtOutputData.Columns.Add("CUSTOMFIELD64", typeof(string));
                dtOutputData.Columns.Add("CUSTOMFIELD65", typeof(string));
                dtOutputData.Columns.Add("CUSTOMFIELD66", typeof(string));
                dtOutputData.Columns.Add("CUSTOMFIELD67", typeof(string));
                dtOutputData.Columns.Add("CUSTOMFIELD68", typeof(string));
                dtOutputData.Columns.Add("CUSTOMFIELD69", typeof(string));
                dtOutputData.Columns.Add("CUSTOMFIELD70", typeof(string));
                dtOutputData.Columns.Add("CUSTOMFIELD71", typeof(string));
                dtOutputData.Columns.Add("CUSTOMFIELD72", typeof(string));
                dtOutputData.Columns.Add("CUSTOMFIELD73", typeof(string));
                dtOutputData.Columns.Add("CUSTOMFIELD74", typeof(string));
                dtOutputData.Columns.Add("CUSTOMFIELD75", typeof(string));
                dtOutputData.Columns.Add("CUSTOMFIELD76", typeof(string));
                dtOutputData.Columns.Add("CUSTOMFIELD77", typeof(string));
                dtOutputData.Columns.Add("CUSTOMFIELD78", typeof(string));
                dtOutputData.Columns.Add("CUSTOMFIELD79", typeof(string));
                dtOutputData.Columns.Add("CUSTOMFIELD80", typeof(string));
                dtOutputData.Columns.Add("CUSTOMFIELD81", typeof(string));
                dtOutputData.Columns.Add("CUSTOMFIELD82", typeof(string));
                dtOutputData.Columns.Add("CUSTOMFIELD83", typeof(string));
                dtOutputData.Columns.Add("CUSTOMFIELD84", typeof(string));
                dtOutputData.Columns.Add("CUSTOMFIELD85", typeof(string));
                dtOutputData.Columns.Add("CUSTOMFIELD86", typeof(string));
                dtOutputData.Columns.Add("CUSTOMFIELD87", typeof(string));
                dtOutputData.Columns.Add("CUSTOMFIELD88", typeof(string));
                dtOutputData.Columns.Add("CUSTOMFIELD89", typeof(string));
                dtOutputData.Columns.Add("CUSTOMFIELD90", typeof(string));
                dtOutputData.Columns.Add("CUSTOMFIELD91", typeof(string));
                dtOutputData.Columns.Add("CUSTOMFIELD92", typeof(string));
                dtOutputData.Columns.Add("CUSTOMFIELD93", typeof(string));
                dtOutputData.Columns.Add("CUSTOMFIELD94", typeof(string));
                dtOutputData.Columns.Add("CUSTOMFIELD95", typeof(string));
                dtOutputData.Columns.Add("CUSTOMFIELD96", typeof(string));
                dtOutputData.Columns.Add("CUSTOMFIELD97", typeof(string));
                dtOutputData.Columns.Add("CUSTOMFIELD98", typeof(string));
                dtOutputData.Columns.Add("CUSTOMFIELD99", typeof(string));
                dtOutputData.Columns.Add("CUSTOMFIELD100", typeof(string));

                foreach(DataRow row in dtInputData.Rows)
                {
                    DataRow dataRow = dtOutputData.NewRow();

                    dataRow["PROCESSNAME"]=processname;
                    dataRow["PROCESSFIELD1"] = processfield1;
                    dataRow["PROCESSFIELD2"] = processfield2;
                    dataRow["PROCESSFIELD3"] = processfield3;
                    dataRow["PROCESSFIELD4"] = processfield4;
                    dataRow["PROCESSFIELD5"] = processfield5;
                    dataRow["PROCESSFIELD6"] = processfield6;
                    dataRow["PROCESSFIELD7"] = processfield7;
                    dataRow["PROCESSFIELD8"] = processfield8;
                    dataRow["PROCESSFIELD9"] = processfield9;
                    dataRow["PROCESSFIELD10"] = processfield10;

                    for (int i = 0; i < inputtablecolcount; i++)
                    {
                        dataRow[11 + i] = row[i];
                    }

                    dtOutputData.Rows.Add(dataRow);
                }


            }
            catch (Exception)
            {

                throw;
            }

            return dtOutputData;
        }

        public async Task<bool> ProcessDataAdotoSQL(DataSet srcDataSet, string dbDestinationTblNm, List<string> dbDestTableList, bool blncolumnMappingActionSts = false)
        {
            Boolean datatransferSts = false;
            try
            {
                if (srcDataSet != null && srcDataSet.Tables.Count > 0)
                {
                    foreach (var table in srcDataSet.Tables)
                    {
                        using (SqlConnection objSqlConn = new SqlConnection(DbConnectionString))
                        {
                            objSqlConn.Open();
                            if (dbDestTableList != null && dbDestTableList.Count > 0)
                            {
                                //Write Code if any validation on Table Data Required or Data Require to delete first.
                            }

                            using (SqlBulkCopy objSqlBulkCopy = new SqlBulkCopy(objSqlConn))
                            {
                                objSqlBulkCopy.BatchSize = 100000;
                                objSqlBulkCopy.BulkCopyTimeout = 1000;
                                objSqlBulkCopy.DestinationTableName = dbDestinationTblNm;
                                objSqlBulkCopy.ColumnMappings.Clear();

                                if (blncolumnMappingActionSts)
                                {
                                    foreach (DataColumn objcolumn in srcDataSet.Tables[0].Columns)
                                    {
                                        objSqlBulkCopy.ColumnMappings.Add(objcolumn.ColumnName, objcolumn.ColumnName.ToUpper());
                                    }
                                }

                                await objSqlBulkCopy.WriteToServerAsync(ProcessGenericAdoDataset(srcDataSet.Tables[0], "INDIVIDUAL_CATEGORY_MASTER").CreateDataReader());
                                datatransferSts = true;
                            }
                        }
                    }
                }

            }
            catch (Exception)
            {
                datatransferSts = false;
                throw;
            }
            finally
            {
                if (dbDestTableList != null)
                { dbDestTableList.Clear(); }


                if (srcDataSet != null)
                {
                    srcDataSet = null;
                }

            }

            return datatransferSts;
            ;
        }
    }
}
