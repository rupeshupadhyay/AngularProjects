﻿using Microsoft.Extensions.DependencyInjection;
using SQLDataAccess;


namespace ApplicationLayer
{
    public static class ApplicationDIService
    {
        public static IServiceCollection AddApplicationServices(this IServiceCollection services)
        {
            services.AddSingleton<ISqlDataHelper, SqlDataHelper>();
            return services;
        }
    }
}
