import { EventDto } from './event-dto';

describe('EventDto', () => {
  it('should create an instance', () => {
    expect(new EventDto()).toBeTruthy();
  });
});
