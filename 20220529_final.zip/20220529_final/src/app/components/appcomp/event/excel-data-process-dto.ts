export class ExcelDataProcessDto 
{
    eventID: string ="";
    uploadGuid: string="";
    userName: string="";
}
