﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ApplicationLayer.Dtos
{
    public class Annexure6Dto
    {
        public string? S_no { get; }
        public string? Pan { get; }
        public string? Name { get; }
        public string? Pan_allotment_date { get; }
        public string? Pan_aadhaar_link_status { get; }
        public string? Specified_person_206ab_206cca { get; }
        public string? Created_date { get; }


    }
}
