﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using ApplicationLayer.Repositories;
using ApplicationLayer.Models;
using System.Net;
using ApplicationLayer.Dtos;

namespace EventDataAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class EventController : ControllerBase
    {
        private readonly IEventRepository _eventRepository;
        private readonly ILogger<EventController> _logger;
        private readonly IConfiguration _configuration;

        public EventController(IEventRepository eventRepository, ILogger<EventController> logger, IConfiguration configuration)
        {
            _eventRepository = eventRepository ?? throw new ArgumentNullException(nameof(eventRepository));
            _configuration = configuration ?? throw new ArgumentNullException(nameof(configuration));
            
            _logger = logger ?? throw new ArgumentNullException(nameof(logger));
        }

        [HttpGet]
        [ProducesResponseType(typeof(IEnumerable<EventDto>), (int) HttpStatusCode.OK)]
        public async Task<ActionResult<IEnumerable<EventDto>>> GetEvent()
        {
            try
            {
                _eventRepository.DbConnectionString =_configuration.GetValue<string>("DatabaseSettings:ConnectionStrings");
                return Ok(await _eventRepository.GetAllEvents());
             }
            catch (Exception ex)
            {
                return Problem(ex.Message);
            }
        }

        [HttpGet("{id}/DupPan", Name = "GetDupPan")]
        [ProducesResponseType(typeof(IEnumerable<Annxure2>), (int)HttpStatusCode.OK)]
        public async Task<ActionResult<IEnumerable<Annxure2>>> GetDupPan(int id)
        {
            try
            {
                _eventRepository.DbConnectionString = _configuration.GetValue<string>("DatabaseSettings:ConnectionStrings");
                return Ok(await _eventRepository.GetAnnxure2(id));
            }
            catch (Exception ex)
            {
                return Problem(ex.Message);
            }
        }

        [HttpGet("{id}", Name = "GetEvent")]
        [ProducesResponseType((int)HttpStatusCode.NotFound)]
        [ProducesResponseType((int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(Event), (int)HttpStatusCode.OK)]
        public async Task<ActionResult<EventDto>> GetEventById(int id)
        {
            try
            {
                _eventRepository.DbConnectionString = _configuration.GetValue<string>("DatabaseSettings:ConnectionStrings");
                var results = await _eventRepository.GetEvent(id);
                if (results == null) return NotFound();
                return Ok(results);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [HttpPost]
        [Consumes("application/json")]
        public async Task<IActionResult> AddNewEvent([FromBody] EventDto ev)
        {
            try
            {
                _eventRepository.DbConnectionString = _configuration.GetValue<string>("DatabaseSettings:ConnectionStrings");
                await _eventRepository.AddNewEvent(ev);
                return Ok();
            }
            catch (Exception ex)
            {
                return Problem(ex.Message);
            }
        }

        [HttpPost("id")]
        [Consumes("application/json")]
        public async Task<IActionResult> ProcessEventData([FromBody] ExcelDataProcessDto ev)
        {
            try
            {
                _eventRepository.DbConnectionString = _configuration.GetValue<string>("DatabaseSettings:ConnectionStrings");

                await _eventRepository.ProcessEventData(ev);
                return Ok();
            }
            catch (Exception ex)
            {
                return Problem(ex.Message);
            }
        }

        [HttpGet("{id}/Annx1", Name = "GetAnnexure1")]
        [ProducesResponseType(typeof(IEnumerable<Annexure1Dto>), (int)HttpStatusCode.OK)]
        public async Task<ActionResult<IEnumerable<Annexure1Dto>>> GetAnnexure1(int id)
        {
            try
            {
                _eventRepository.DbConnectionString = _configuration.GetValue<string>("DatabaseSettings:ConnectionStrings");
                return Ok(await _eventRepository.GetAnnxure1(id));
            }
            catch (Exception ex)
            {
                return Problem(ex.Message);
            }
        }

        [HttpGet("{id}/Annx5", Name = "GetAnnexure5")]
        [ProducesResponseType(typeof(IEnumerable<Annexure5Dto>), (int)HttpStatusCode.OK)]
        public async Task<ActionResult<IEnumerable<Annexure5Dto>>> GetAnnexure5(int id)
        {
            try
            {
                _eventRepository.DbConnectionString = _configuration.GetValue<string>("DatabaseSettings:ConnectionStrings");
                return Ok(await _eventRepository.GetAnnxure5(id));
            }
            catch (Exception ex)
            {
                return Problem(ex.Message);
            }
        }

        [HttpGet("{id}/Annx6", Name = "GetAnnexure6")]
        [ProducesResponseType(typeof(IEnumerable<Annexure6Dto>), (int)HttpStatusCode.OK)]
        public async Task<ActionResult<IEnumerable<Annexure6Dto>>> GetAnnexure6(int id)
        {
            try
            {
                _eventRepository.DbConnectionString = _configuration.GetValue<string>("DatabaseSettings:ConnectionStrings");
                return Ok(await _eventRepository.GetAnnxure6(id));
            }
            catch (Exception ex)
            {
                return Problem(ex.Message);
            }
        }

        [HttpGet("{id}/Annx13", Name = "GetAnnexure13")]
        [ProducesResponseType(typeof(IEnumerable<Annexure13Dto>), (int)HttpStatusCode.OK)]
        public async Task<ActionResult<IEnumerable<Annexure13Dto>>> GetAnnexure14(int id)
        {
            try
            {
                _eventRepository.DbConnectionString = _configuration.GetValue<string>("DatabaseSettings:ConnectionStrings");
                return Ok(await _eventRepository.GetAnnxure13(id));
            }
            catch (Exception ex)
            {
                return Problem(ex.Message);
            }
        }

        [HttpPut]
        [Consumes("application/json")]
        public async Task<IActionResult> UpdateEvent(EventDto ev)
        {
            try
            {
                _eventRepository.DbConnectionString = _configuration.GetValue<string>("DatabaseSettings:ConnectionStrings");
                await _eventRepository.UpdateEvent(ev);
                return Ok();
            }
            catch (Exception ex)
            {
                return Problem(ex.Message);
            }
        }

        [HttpDelete("{id}")]
        [HttpDelete]
        public async Task<IActionResult> DeleteEvent(int id)
        {
            try
            {
                _eventRepository.DbConnectionString = _configuration.GetValue<string>("DatabaseSettings:ConnectionStrings");
                await _eventRepository.DeleteEvent(id);
                return Ok();
            }
            catch (Exception ex)
            {
                return Problem(ex.Message);
            }
        }

    }
}
