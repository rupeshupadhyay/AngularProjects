﻿using ApplicationLayer.Common;

namespace ApplicationLayer.Models
{
    public class Event : EntityBase
    {
        public int EventID { get; set; }
        public string? EntityName { get; set; }
        public string? PanCardNum { get; set; }
        public string? JobWorkOrderNum { get; set; }
        public string? EventDate { get; set; }

    }
}
