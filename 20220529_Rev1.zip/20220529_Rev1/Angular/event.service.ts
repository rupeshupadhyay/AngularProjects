import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http'; // Http Client 
import { Observable } from 'rxjs'; // Subscription Metod 
import { EventDto }  from './event-dto'; // Model Class Dto for Data Transfer Activities.
import { DupPanDto } from './dup-pan-dto'; 
import { ExcelDataProcessDto } from './excel-data-process-dto';
import { AppConfigService } from '../../../services/common/app-config.service';
import { Annexure1Dto } from './annexure1-dto';
import { Annexure3Dto } from './annexure3-dto';
import { Annexure4Dto } from './annexure4-dto';
import { Annexure5Dto } from './annexure5-dto';
import { Annexure6Dto } from './annexure6-dto';
import { Annexure7Dto } from './annexure7-dto';
import { Annexure8Dto } from './annexure8-dto';
import { Annexure9Dto } from './annexure9-dto';
import { Annexure10Dto } from './annexure10-dto';
import { Annexure11Dto } from './annexure11-dto';
import { Annexure13Dto } from './annexure13-dto';

@Injectable()
export class EventService {

  headers = new HttpHeaders({ 'Content-Type': 'application/json' });
  baseUrl:string;

  //HttpClient Injection
  constructor(private httpclient:HttpClient,private appSvc:AppConfigService) 
  { 
    this.baseUrl= appSvc.appApiUrl;
  }

  // Get All Events
  getEventList(): Observable<EventDto[]>
  {
    //Get Command
    return this.httpclient.get<EventDto[]>(this.baseUrl+'/Event');
  }

  // Get Selected Event by Event ID
  getEventListID(eventid:string): Observable<EventDto>
  {
    //Get Command
    return this.httpclient.get<EventDto>(this.baseUrl+'/Event/'+eventid);
  }

  // Get Duplicate Pan Data
  getDupPanList(eventid:string): Observable<DupPanDto[]>
  {
    //Get Command
    return this.httpclient.get<DupPanDto[]>(this.baseUrl+'/Event/'+eventid+''+'/DupPan');
  }

  // Get Annexure1 Data
  getAnnexure1List(eventid:string): Observable<Annexure1Dto[]>
  {
    //Get Command
    return this.httpclient.get<Annexure1Dto[]>(this.baseUrl+'/Event/'+eventid+''+'/Annx1');
  }

  // Get Annexure3 Data
  getAnnexure3List(eventid:string): Observable<Annexure3Dto[]>
  {
    //Get Command
    return this.httpclient.get<Annexure3Dto[]>(this.baseUrl+'/Event/'+eventid+''+'/Annx3');
  }

  // Get Annexure4 Data
  getAnnexure4List(eventid:string): Observable<Annexure4Dto[]>
  {
    //Get Command
    return this.httpclient.get<Annexure4Dto[]>(this.baseUrl+'/Event/'+eventid+''+'/Annx4');
  }

   // Get Annexure5 Data
   getAnnexure5List(eventid:string): Observable<Annexure5Dto[]>
   {
     //Get Command
     return this.httpclient.get<Annexure5Dto[]>(this.baseUrl+'/Event/'+eventid+''+'/Annx5');
   }

   // Get Annexure6 Data
   getAnnexure6List(eventid:string): Observable<Annexure6Dto[]>
   {
     //Get Command
     return this.httpclient.get<Annexure6Dto[]>(this.baseUrl+'/Event/'+eventid+''+'/Annx6');
   }

    // Get Annexure7 Data
    getAnnexure7List(eventid:string): Observable<Annexure7Dto[]>
    {
        //Get Command
        return this.httpclient.get<Annexure7Dto[]>(this.baseUrl+'/Event/'+eventid+''+'/Annx7');
    }

    // Get Annexure8 Data
    getAnnexure8List(eventid:string): Observable<Annexure8Dto[]>
    {
        //Get Command
        return this.httpclient.get<Annexure8Dto[]>(this.baseUrl+'/Event/'+eventid+''+'/Annx8');
    }

    // Get Annexure9 Data
    getAnnexure9List(eventid:string): Observable<Annexure9Dto[]>
    {
        //Get Command
        return this.httpclient.get<Annexure9Dto[]>(this.baseUrl+'/Event/'+eventid+''+'/Annx9');
    }

    // Get Annexure10 Data
    getAnnexure10List(eventid:string): Observable<Annexure10Dto[]>
    {
        //Get Command
        return this.httpclient.get<Annexure10Dto[]>(this.baseUrl+'/Event/'+eventid+''+'/Annx10');
    }

    // Get Annexure11 Data
    getAnnexure11List(eventid:string): Observable<Annexure11Dto[]>
    {
        //Get Command
        return this.httpclient.get<Annexure11Dto[]>(this.baseUrl+'/Event/'+eventid+''+'/Annx11');
    }

   // Get Annexure13 Data
   getAnnexure13List(eventid:string): Observable<Annexure13Dto[]>
   {
     //Get Command
     return this.httpclient.get<Annexure13Dto[]>(this.baseUrl+'/Event/'+eventid+''+'/Annx13');
   }
  
  // Post New Event Data
  postEventdata(eventdto:EventDto): Observable<EventDto>
  {
    console.log(EventDto);

    
    //let body = JSON.stringify(EventDto); 

   // console.log(body); 
    console.log(this.headers);
    //Post Command
    return this.httpclient.post<EventDto>(this.baseUrl+'/Event',eventdto,{headers:this.headers});
  }

  // Update Event Data
  putEventdata(eventdto:EventDto): Observable<any>
  {
    return this.httpclient.put<EventDto>(this.baseUrl+'/Event',eventdto,{headers:this.headers});
  }

  // Delete Event Data
  deleteEventdata(eventid:string): Observable<any>
  {
    return this.httpclient.delete(this.baseUrl+'/Event/'+eventid,{headers:this.headers});
  }

  // Process Excel Data
  postExceldata(exceldataprocessdto:ExcelDataProcessDto): Observable<string>
  {
    console.log(exceldataprocessdto);
    console.log(this.headers);
    console.log(this.baseUrl+'/Event/Id');
    //Post Command
    return this.httpclient.post<string>(this.baseUrl+'/Event/Id',exceldataprocessdto,{headers:this.headers});
  }

}
