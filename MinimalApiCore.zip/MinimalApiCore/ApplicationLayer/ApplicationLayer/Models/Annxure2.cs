﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ApplicationLayer.Models
{
    public class Annxure2
    {

        public string? bfitpan { get; set; }

        public string? dpid { get; set; }

        public string? holderfolio{ get; set; }

        public string? holder { get; set; }


    }
}
