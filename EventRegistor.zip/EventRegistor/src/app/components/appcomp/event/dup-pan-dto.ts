export class DupPanDto 
{
    bfitpan: string;
    dpid: string;
    holderfolio: string;
    holder: string;

    constructor()
    {
        this.bfitpan='';
        this.dpid='';
        this.holderfolio='';
        this.holder='';   
    }

}
