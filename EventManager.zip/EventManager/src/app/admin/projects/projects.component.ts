import { Component, OnInit } from '@angular/core';
import { Project } from '../../project';
import { ProjectsService } from 'src/app/projects.service';

@Component({
  selector: 'app-projects',
  templateUrl: './projects.component.html',
  styleUrls: ['./projects.component.scss']
})

export class ProjectsComponent implements OnInit {

  projects: Project[] = [];
  objNewProject: Project = new Project();

  constructor(private objPrjSvc: ProjectsService) {

  }



  ngOnInit() {
    //Implementing Subscriber
    this.objPrjSvc.getProjectList().subscribe(
      (response: Project[]) => {
        this.projects = response;
      }
    );
  }

  onSaveClick() {
    this.objPrjSvc.postProjectdata(this.objNewProject).subscribe(
      (response: Project) => {
        //Add Project to Grid
        console.log(response);

        var p:Project= response;
                
        this.projects.push(p);

        console.log(this.projects);
       
        //Clear New Project Dialog - TextBoxes
        this.objNewProject.projectID = 0;
        this.objNewProject.projectName = "";
        this.objNewProject.dateOfStart = "";
        this.objNewProject.teamSize = 0;

      },
      (error) => {
        console.log(error);
      });
  }

}
