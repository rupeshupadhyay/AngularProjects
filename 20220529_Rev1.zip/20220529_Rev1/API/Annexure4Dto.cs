﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ApplicationLayer.Dtos
{
    public class Annexure4Dto
    {
        public string? Dpid { get; }
        public string? Holder_folio { get; }
        public string? Dpid_folio { get; }
        public string? Bfitpan { get; }
        public string? Residential { get; }
        public string? Currentdividend { get; }
        public string? Olddividend { get; }
        public string? Iepfcurrentdividend { get; }
        public string? Iepfolddividend { get; }
        public string? Totaldividend { get; }
        public string? Typeofshareholder { get; }
        public string? Panverification { get; }
        public string? Section206ab { get; }
        public string? Panstatus { get; }
        public string? Thresholdbenefit { get; }
        public string? Dualresidentstatus { get; }
        public string? Panaggreation { get; }

    }
}
