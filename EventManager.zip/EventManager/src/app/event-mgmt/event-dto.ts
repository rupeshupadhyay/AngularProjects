// Event Model Class
export class EventDto 
{
    eventID: number;
    entityName: string;
    panCardNum: string;
    jobWorkOrderNum: string;
    eventDate: string;
    createdBy: string;
    createdDate: string;
    lastModifiedBy: string;
    lastModifiedDate: string;

    constructor()
    {
        this.eventID= 0;
        this.entityName="";
        this.panCardNum="";
        this.jobWorkOrderNum="";
        this.eventDate="";
        this.createdBy="";
        this.createdDate="";
        this.lastModifiedBy="";
        this.lastModifiedDate="";

    }
}
