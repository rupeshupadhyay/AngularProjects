﻿using Microsoft.AspNetCore.Mvc;
using ApplicationLayer.Repositories;
using System.Net;

namespace EventDataAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ExcelDataProcessController : ControllerBase
    {
        private readonly IWebHostEnvironment _webHostEnvironment;
        private readonly IUploadFiles _uploadFiles;
        private readonly IConfiguration _configuration;

        public ExcelDataProcessController(IWebHostEnvironment webHostEnvironment, IUploadFiles uploadfiles, IConfiguration configuration)
        {
            _webHostEnvironment = webHostEnvironment ?? throw new ArgumentNullException(nameof(webHostEnvironment));
            _configuration = configuration ?? throw new ArgumentNullException(nameof(configuration));
            _uploadFiles = uploadfiles;
        }

        [Route("Upload/{processid}")]
        [HttpPost, DisableRequestSizeLimit]
        [ProducesResponseType((int)HttpStatusCode.NotFound)]
        [ProducesResponseType((int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(String), (int)HttpStatusCode.OK)]
        public async Task<IActionResult> Upload(string? processid)
        {
            List<IFormFile> lstInputFiles=new();
            string? strMessage;
            try
            {
                _uploadFiles.DbConnectionString = _configuration.GetValue<string>("DatabaseSettings:ConnectionStrings");
                var formCollection = await Request.ReadFormAsync();
                var inputfiles = formCollection.Files;

                if (inputfiles.Count == 0)
                    return BadRequest();

                foreach (var file in inputfiles)
                {
                    lstInputFiles.Add(file);
                }
                var res = await _uploadFiles.ProcessFileData(processid, lstInputFiles);
                strMessage = _uploadFiles.ProcessField1;
                return Ok(strMessage);
            }
            catch(Exception ex)
            { return BadRequest(ex.Message); }
        }
    }
}
