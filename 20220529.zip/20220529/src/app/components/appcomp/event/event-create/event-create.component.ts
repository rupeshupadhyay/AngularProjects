import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute} from '@angular/router';
import { EventDto } from '../event-dto';
import { EventService } from '../event.service';

@Component
({
  selector: 'app-event-create',
  templateUrl: './event-create.component.html'
})
export class EventCreateComponent implements OnInit 
{
  objNewEvent:EventDto = new EventDto();

  constructor(private eventsvc:EventService,private route:ActivatedRoute,private router:Router) { }

  ngOnInit(): void {}

  onSaveClick() 
  {
    console.log(this.objNewEvent);
    this.eventsvc.postEventdata(this.objNewEvent).subscribe(
      (response?: EventDto) => {
        //Add Project to Grid
        console.log(response);
        this.router.navigateByUrl('\events');
      },
     (error:any) => {console.log(error);this.router.navigate(['events']);}
      );
  }

  onCancelClick(){this.router.navigateByUrl('\events', {replaceUrl: true});}
}
