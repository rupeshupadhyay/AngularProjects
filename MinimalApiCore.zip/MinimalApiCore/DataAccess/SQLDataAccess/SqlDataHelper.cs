﻿using Dapper;
using Microsoft.Extensions.Configuration;
using System.Data;
using System.Data.SqlClient;

namespace SQLDataAccess
{
    public class SqlDataHelper : ISqlDataHelper
    {
        //private readonly IConfiguration _config;
        private readonly string  _constr;

        public SqlDataHelper(IConfiguration config)
        {
            //_config = config;
            _constr = "Data Source =.; Initial Catalog = EventDB; User ID = scott; pwd = tiger; ";
        }

        public async Task<IEnumerable<T>> GetData<T, U>(
            string storedProcedure,
            U parameters,
            string connectionId = "Default")
        {
            using IDbConnection connection = new SqlConnection(_constr);

            return await connection.QueryAsync<T>(storedProcedure, parameters,
                commandType: CommandType.StoredProcedure);
        }

        public async Task SaveData<T>(
            string storedProcedure,
            T parameters,
            string connectionId = "Default")
        {
            using IDbConnection connection = new SqlConnection(_constr) ;

            await connection.ExecuteAsync(storedProcedure, parameters,
                commandType: CommandType.StoredProcedure);
        }

        public async Task<bool> ProcessDataAdotoSQL(DataSet srcDataSet, string dbDestinationTblNm, List<string> dbDestTableList, bool blncolumnMappingActionSts = false)
        {
            Boolean datatransferSts = false;
            try
            {
                if (srcDataSet != null && srcDataSet.Tables.Count > 0)
                {
                    foreach (var table in srcDataSet.Tables)
                    {
                        using (SqlConnection objSqlConn = new SqlConnection(_constr))
                        {
                            objSqlConn.Open();
                            if (dbDestTableList != null && dbDestTableList.Count > 0)
                            {
                                //Write Code if any validation on Table Data Required or Data Require to delete first.
                            }

                            using (SqlBulkCopy objSqlBulkCopy = new SqlBulkCopy(objSqlConn))
                            {
                                objSqlBulkCopy.BatchSize = 100000;
                                objSqlBulkCopy.BulkCopyTimeout = 1000;
                                objSqlBulkCopy.DestinationTableName = dbDestinationTblNm;
                                objSqlBulkCopy.ColumnMappings.Clear();

                                if (blncolumnMappingActionSts)
                                {
                                    foreach (DataColumn objcolumn in srcDataSet.Tables[0].Columns)
                                    {
                                        objSqlBulkCopy.ColumnMappings.Add(objcolumn.ColumnName, objcolumn.ColumnName.ToUpper());
                                    }
                                }

                                await objSqlBulkCopy.WriteToServerAsync(srcDataSet.Tables[0].CreateDataReader());
                                datatransferSts = true;
                            }
                        }
                    }
                }

            }
            catch (Exception)
            {
                datatransferSts = false;
                throw;
            }
            finally
            {
                if (dbDestTableList != null)
                { dbDestTableList.Clear(); }


                if (srcDataSet != null)
                {
                    srcDataSet = null;
                }

            }

            return datatransferSts;
            ;
        }
    }
}
