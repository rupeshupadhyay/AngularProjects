﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ApplicationLayer.Models
{
    public class UploadParams
    {
        public string? ProcessName { get; set; }
        //Keep Guid for Data Upload
         public string? ProcessField1 { get; set; }
        // Keep Destination Table Name
        public string? ProcessField2 { get; set; }
        // Keep Procedure Name
        public string? ProcessField3 { get; set; }
        public string? ProcessField4 { get; set; }
        public string? ProcessField5 { get; set; }
        public string? ProcessField6 { get; set; }
        public string? ProcessField7 { get; set; }
        public string? ProcessField8 { get; set; }
        public string? ProcessField9 { get; set; }
        public string? ProcessField10 { get; set; }
    }
}
