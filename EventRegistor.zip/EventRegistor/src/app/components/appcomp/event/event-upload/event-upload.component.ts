import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-event-upload',
  templateUrl: './event-upload.component.html'
})
export class EventUploadComponent implements OnInit {
  eventID:string="0";
  entityName:string="";
  eventDate:string="";
  exportDupPanHeaders:[]=[];
  exportDupLineItems:[]=[];
  
  constructor() { }

  ngOnInit(): void 
  {  
    this.eventID=sessionStorage['app.eventid']
    this.entityName=sessionStorage['app.entitynm'];
    this.eventDate=sessionStorage['app.eventdate'];
  }



}
