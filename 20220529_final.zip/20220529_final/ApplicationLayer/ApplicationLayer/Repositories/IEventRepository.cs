﻿using ApplicationLayer.Dtos;
using ApplicationLayer.Models;

namespace ApplicationLayer.Repositories
{
    public interface IEventRepository
    {
        public string? DbConnectionString { get; set; }
        Task DeleteEvent(int id);
        Task<EventDto?> GetEvent(int id);
        Task<IEnumerable<Annxure2>> GetAnnxure2(int id);
        Task<IEnumerable<EventDto>> GetAllEvents();
        Task AddNewEvent(EventDto evt);
        Task ProcessEventData(ExcelDataProcessDto evt);
        Task UpdateEvent(EventDto evt);
        Task<IEnumerable<Annexure1Dto>> GetAnnxure1(int id);
        Task<IEnumerable<Annexure3Dto>> GetAnnxure3(int id);
        Task<IEnumerable<Annexure5Dto>> GetAnnxure5(int id);
        Task<IEnumerable<Annexure6Dto>> GetAnnxure6(int id);
        Task<IEnumerable<Annexure7Dto>> GetAnnxure7(int id);
        Task<IEnumerable<Annexure13Dto>> GetAnnxure13(int id);
    }
}
