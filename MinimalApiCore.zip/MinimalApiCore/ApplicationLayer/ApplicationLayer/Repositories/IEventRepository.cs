﻿using ApplicationLayer.Dtos;
using ApplicationLayer.Models;


namespace ApplicationLayer.Repositories
{
    public interface IEventRepository
    {
        Task DeleteEvent(int id);
        Task<EventDto?> GetEvent(int id);

        Task<IEnumerable<Annxure2>> GetAnnxure2(int id);

        Task<IEnumerable<EventDto>> GetAllEvents();
        Task AddNewEvent(EventDto evt);

        Task UpdateEvent(EventDto evt);
    }
}
