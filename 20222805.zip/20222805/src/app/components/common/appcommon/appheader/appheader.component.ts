import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-appheader',
  templateUrl: './appheader.component.html'
})
export class AppheaderComponent implements OnInit {

  title:string='Dividend Registor';
  
  headerroutes= [
    {"link":"/events","title":"Event"}
  ];

  constructor() { }

  ngOnInit(): void {
  }

}
