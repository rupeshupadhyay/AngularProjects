﻿using ApplicationLayer.Contracts;
using ApplicationLayer.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;
using SQLDataAccess;
using ApplicationLayer.Dtos;

namespace ApplicationLayer.Repositories
{
    public class EventRepository : IEventRepository
    {
        private readonly ISqlDataHelper _db;

        public string? DbConnectionString { get; set; }

        public EventRepository(ISqlDataHelper db)
        {
            db.DbConnectionString = DbConnectionString;
            _db = db;

        }

        public async Task AddNewEvent(EventDto ev)
        {
            _db.DbConnectionString = DbConnectionString;
            await  _db.SaveData("dbo.SPR_EVENT", new
            {
                P_Event_Id = 0,
                P_Event_Entity_Name = ev.EntityName,
                P_Pan_Card_Num = ev.PanCardNum,
                P_Job_Work_Order_Num = ev.JobWorkOrderNum,
                P_Event_Date = ev.EventDate,
                P_App_User_Id = 1,
                P_User_Name = ev.CreatedBy,
                P_Mode = "POST"
            });
        }

        public async Task ProcessEventData(ExcelDataProcessDto ev)
        {
            _db.DbConnectionString = DbConnectionString;
            await _db.SaveData("dbo.SPR_EVENT", new
            {
                P_Event_Id = ev.EventID,
                P_Event_Entity_Name = ev.UploadGuid,
                P_Pan_Card_Num = "",
                P_Job_Work_Order_Num = "",
                P_Event_Date = "",
                P_App_User_Id = 1,
                P_User_Name = ev.UserName,
                P_Mode = "PROCESSEXCEL"
            });
        }

        public async Task DeleteEvent(int id)
        {
            _db.DbConnectionString = DbConnectionString;
            await _db.SaveData("dbo.SPR_EVENT", new
            {
                P_Event_Id = id,
                P_Event_Entity_Name = "",
                P_Pan_Card_Num = "",
                P_Job_Work_Order_Num = "",
                P_Event_Date = "",
                P_App_User_Id = 1,
                P_User_Name = "",
                P_Mode = "DELETE"
            });
        }

        public async Task<IEnumerable<EventDto>> GetAllEvents()
        {
            _db.DbConnectionString = DbConnectionString;
            var results= await _db.GetData<EventDto, dynamic>("dbo.SPR_EVENT", new
            {
                P_Event_Id = 0,
                P_Event_Entity_Name = "",
                P_Pan_Card_Num = "",
                P_Job_Work_Order_Num = "",
                P_Event_Date = "",
                P_App_User_Id = 1,
                P_User_Name = "DEMO",
                P_Mode = "GETALL"
            });

            return results.ToList();
        }

        public async Task<IEnumerable<Annxure2>> GetAnnxure2(int id)
        {
            var results = await _db.GetData<Annxure2, dynamic>("dbo.SPR_EVENT", new
            {
                P_Event_Id = id,
                P_Event_Entity_Name = "",
                P_Pan_Card_Num = "",
                P_Job_Work_Order_Num = "",
                P_Event_Date = "",
                P_App_User_Id = 1,
                P_User_Name = "DEMO",
                P_Mode = "GETDUPPAN"
            });

            return results.ToList();
        }

        public async Task<EventDto?> GetEvent(int id)
        {
            _db.DbConnectionString = DbConnectionString;
            var results = await _db.GetData<EventDto, dynamic>( "dbo.SPR_EVENT", new 
            {
                P_Event_Id = id,
                P_Event_Entity_Name = "",
                P_Pan_Card_Num = "",
                P_Job_Work_Order_Num = "",
                P_Event_Date = "",
                P_App_User_Id = 1,
                P_User_Name = "DEMO",
                P_Mode = "GET"
            });

            return results.FirstOrDefault();
        }

        public async Task UpdateEvent(EventDto ev)
        {
            _db.DbConnectionString = DbConnectionString;
            await _db.SaveData("dbo.SPR_EVENT", new
            {
                P_Event_Id = ev.EventID,
                P_Event_Entity_Name = ev.EntityName,
                P_Pan_Card_Num = ev.PanCardNum,
                P_Job_Work_Order_Num = ev.JobWorkOrderNum,
                P_Event_Date = ev.EventDate,
                P_App_User_Id = 1,
                P_User_Name = ev.CreatedBy,
                P_Mode = "PUT"
            });
        }

        public async Task<IEnumerable<Annexure1Dto>> GetAnnxure1(int id)
        {
            _db.DbConnectionString = DbConnectionString;
            var results = await _db.GetData<Annexure1Dto, dynamic>("dbo.SPR_EVENT", new
            {
                P_Event_Id = id,
                P_Event_Entity_Name = "",
                P_Pan_Card_Num = "",
                P_Job_Work_Order_Num = "",
                P_Event_Date = "",
                P_App_User_Id = 1,
                P_User_Name = "DEMO",
                P_Mode = "GETANN1"
            });

            return results.ToList();
        }
        public async Task<IEnumerable<Annexure5Dto>> GetAnnxure5(int id)
        {
            _db.DbConnectionString = DbConnectionString;
            var results = await _db.GetData<Annexure5Dto, dynamic>("dbo.SPR_EVENT", new
            {
                P_Event_Id = id,
                P_Event_Entity_Name = "",
                P_Pan_Card_Num = "",
                P_Job_Work_Order_Num = "",
                P_Event_Date = "",
                P_App_User_Id = 1,
                P_User_Name = "DEMO",
                P_Mode = "GETANN5"
            });

            return results.ToList();
        }
        public async Task<IEnumerable<Annexure6Dto>> GetAnnxure6(int id)
        {
            _db.DbConnectionString = DbConnectionString;
            var results = await _db.GetData<Annexure6Dto, dynamic>("dbo.SPR_EVENT", new
            {
                P_Event_Id = id,
                P_Event_Entity_Name = "",
                P_Pan_Card_Num = "",
                P_Job_Work_Order_Num = "",
                P_Event_Date = "",
                P_App_User_Id = 1,
                P_User_Name = "DEMO",
                P_Mode = "GETANN6"
            });

            return results.ToList();
        }

        public async Task<IEnumerable<Annexure13Dto>> GetAnnxure13(int id)
        {
            _db.DbConnectionString = DbConnectionString;
            var results = await _db.GetData<Annexure13Dto, dynamic>("dbo.SPR_EVENT", new
            {
                P_Event_Id = id,
                P_Event_Entity_Name = "",
                P_Pan_Card_Num = "",
                P_Job_Work_Order_Num = "",
                P_Event_Date = "",
                P_App_User_Id = 1,
                P_User_Name = "DEMO",
                P_Mode = "GETANN13"
            });

            return results.ToList();
        }
    }
}
