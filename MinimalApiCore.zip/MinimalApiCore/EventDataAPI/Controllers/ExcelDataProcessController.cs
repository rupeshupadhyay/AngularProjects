﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Hosting;
using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using ExcelDataReader;
using SQLDataAccess;
using Microsoft.Extensions.Configuration;

namespace EventDataAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ExcelDataProcessController : ControllerBase
    {
        private readonly IWebHostEnvironment _webHostEnvironment;

        private readonly ISqlDataHelper objHelperDataAccess;

        public ExcelDataProcessController(IWebHostEnvironment webHostEnvironment, ISqlDataHelper sqlDataHelper)
        {
            _webHostEnvironment = webHostEnvironment ?? throw new ArgumentNullException(nameof(webHostEnvironment));
            objHelperDataAccess = sqlDataHelper;
        }

        [Route("Upload/{id}")]
        [HttpPost, DisableRequestSizeLimit]
        public async Task<IActionResult> Upload(string id)
        {
            string tblName = "";

            try
            {
                var formCollection = await Request.ReadFormAsync();
                var inputfiles = formCollection.Files;

                if (inputfiles.Count == 0)
                    return BadRequest();

                switch(id)
                {
                    case "1":
                        tblName = "INDIVIDUAL_CATEGORY_MASTER";
                        break;
                    default: 
                        tblName = "INDIVIDUAL_CATEGORY_MASTER";
                        break;
                }

                string message = "";

                DataSet dsexcelRecordsAll = new DataSet();

                System.Text.Encoding.RegisterProvider(System.Text.CodePagesEncodingProvider.Instance);

                foreach (var file in inputfiles)
                {
                    try
                    {
                        IFormFile Inputfile = null;
                        Stream FileStream = null;
                        IExcelDataReader reader = null;
                        DataSet dsexcelRecords = new DataSet();

                        Inputfile = file;

                        FileStream = Inputfile.OpenReadStream();

                        if (Inputfile != null && FileStream != null)
                        {
                            if (Inputfile.FileName.EndsWith(".xls"))
                            { reader = ExcelReaderFactory.CreateBinaryReader(FileStream); }
                            else if (Inputfile.FileName.EndsWith(".xlsx"))
                            { reader = ExcelReaderFactory.CreateOpenXmlReader(FileStream); }
                            else { message = "The file format is not supported."; }

                            dsexcelRecords = reader.AsDataSet();
                            reader.Close();

                            if (dsexcelRecords != null && dsexcelRecords.Tables.Count > 0)
                            {
                                await objHelperDataAccess.ProcessDataAdotoSQL(dsexcelRecords, tblName, null, false);


                                //DataTable dtExcelRecords = dsexcelRecords.Tables[0];

                                //Write Function to Convert copy data from bulk Copy.
                                //dsexcelRecordsAll.Tables.Add(dsexcelRecords.Tables[0]);
                            }
                            else { message = "Selected file is empty."; }
                        }
                        else { message = "Invalid File."; }
                    }
                    catch (Exception)
                    {

                        throw;
                    }
                }
                    return Ok(message);
                }
                catch(Exception ex)
                { return BadRequest(ex.Message); }
        }

        [Route("UploadExcelData")]
        [HttpPost]
        public IActionResult ProcessExcelFile(List<IFormFile> files)
        {
            try
            {
                if (files.Count == 0)
                    return BadRequest();

                string message = "";

                DataSet dsexcelRecordsAll = new DataSet();

                System.Text.Encoding.RegisterProvider(System.Text.CodePagesEncodingProvider.Instance);

                foreach (var file in files)
                {
                    try
                    {

                    
                    IFormFile Inputfile = null;
                    Stream FileStream = null;
                    IExcelDataReader reader = null;
                    DataSet dsexcelRecords = new DataSet();
                   

                    Inputfile = file;

                    FileStream = Inputfile.OpenReadStream();

                    if (Inputfile != null && FileStream != null)
                    {
                        if (Inputfile.FileName.EndsWith(".xls"))
                        { reader = ExcelReaderFactory.CreateBinaryReader(FileStream); }
                        else if (Inputfile.FileName.EndsWith(".xlsx"))
                        { reader = ExcelReaderFactory.CreateOpenXmlReader(FileStream); }
                        else { message = "The file format is not supported."; }

                        dsexcelRecords = reader.AsDataSet();
                        reader.Close();

                        if (dsexcelRecords != null && dsexcelRecords.Tables.Count > 0)
                        {
                           objHelperDataAccess.ProcessDataAdotoSQL(dsexcelRecords, "sampleTable1", null, false);

                            
                            //DataTable dtExcelRecords = dsexcelRecords.Tables[0];

                            //Write Function to Convert copy data from bulk Copy.
                            //dsexcelRecordsAll.Tables.Add(dsexcelRecords.Tables[0]);
                        }
                        else { message = "Selected file is empty."; }
                    }
                    else { message = "Invalid File."; }
                    }
                    catch (Exception)
                    {

                        throw;
                    }
                }

                return Ok(message);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
    }
}
