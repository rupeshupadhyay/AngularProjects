import { NgModule,APP_INITIALIZER } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { AppcommonModule } from './components/common/appcommon/appcommon.module';
import { AppcompModule } from './components/appcomp/appcomp.module';
import {HttpClientModule} from '@angular/common/http';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { AppConfigService } from './services/common/app-config.service';
import { UtilService } from './services/common/util.service';

const appInitializerFn = (appConfig: AppConfigService) => {
  return () => {
      return appConfig.loadAppConfig();
  }
};

@NgModule({
  declarations: [
    AppComponent
  ],
  imports: [
    BrowserModule,AppRoutingModule, HttpClientModule, FormsModule, ReactiveFormsModule,
    AppcommonModule,AppcompModule
  ],
  providers: [
    UtilService,
    AppConfigService,
        {
            provide: APP_INITIALIZER,
            useFactory: appInitializerFn,
            multi: true,
            deps: [AppConfigService]
        }
  ],
  bootstrap: [AppComponent]
})
export class AppModule { 
  
}
