﻿using ApplicationLayer.Common;
using System.Linq;
using System.Threading;
using System.IO;
using Microsoft.AspNetCore.Http;
using System.Data;
using ExcelDataReader;
using SQLDataAccess;


namespace ApplicationLayer.Repositories
{
    public class UploadFiles:IUploadFiles
    {
        //Keep Process Name Identified
        public string? ProcessName { get; set; }
        //Keep Guid for Data Upload
        public string? ProcessField1 { get; set; }
        // Keep Destination Table Name
        public string? ProcessField2 { get; set; }
        // Keep Procedure Name
        public string? ProcessField3 { get; set; }
        public string? ProcessField4 { get; set; }
        public string? ProcessField5 { get; set; }
        public string? ProcessField6 { get; set; }
        public string? ProcessField7 { get; set; }
        public string? ProcessField8 { get; set; }
        public string? ProcessField9 { get; set; }
        public string? ProcessField10 { get; set; }

        private readonly ISqlDataHelper _db;
        public string? DbConnectionString { get; set; }

        public UploadFiles(ISqlDataHelper db)
        {
            //db.DbConnectionString = DbConnectionString;
            _db = db;
        }

        public async Task<string> ProcessFileData(string? Processname, List<IFormFile> Files)
        {
            string? strProcessMsg;
            SetUploadParameter(Processname);
            string? strDataGuid;
            
            try
            {
                strDataGuid = ProcessField1;
                _db.DbConnectionString = DbConnectionString;
               var inputfiles = Files;   

               if (inputfiles.Count == 0){throw new Exception("No File to Upload.");}

                DataSet dsexcelRecordsAll = new DataSet();
                System.Text.Encoding.RegisterProvider(System.Text.CodePagesEncodingProvider.Instance);
                foreach (var file in inputfiles)
                {
                    try
                    {
                        IFormFile? Inputfile = null;
                        Stream? FileStream = null;
                        IExcelDataReader? reader = null;
                        DataSet dsexcelRecords = new DataSet();
                        Inputfile = file;
                        FileStream = Inputfile.OpenReadStream();

                        if (Inputfile != null && FileStream != null)
                        {
                            if (Inputfile.FileName.EndsWith(".xls"))
                            { reader = ExcelReaderFactory.CreateBinaryReader(FileStream); }
                            else if (Inputfile.FileName.EndsWith(".xlsx"))
                            { reader = ExcelReaderFactory.CreateOpenXmlReader(FileStream); }
                            else { strProcessMsg = "The file format is not supported."; }

                            dsexcelRecords = reader.AsDataSet();
                            reader.Close();
                            if (dsexcelRecords != null && dsexcelRecords.Tables.Count > 0)
                            {
                                await _db.ProcessDataAdotoSQL(dsexcelRecords, null, false, Processname, ProcessField1, ProcessField2, ProcessField3, ProcessField4, ProcessField5,
                                ProcessField6, ProcessField7, ProcessField8, ProcessField9, ProcessField10);
                            }
                            else { throw new Exception("Selected file is empty."); }
                        }
                        else { throw new Exception("Invalid File."); }
                   }
                    catch (Exception) { throw; }
                }
                return strDataGuid ?? "";
            }
            catch (Exception ex)
            {
                strProcessMsg = "Failed." + ex.Message;
                return strProcessMsg;
            }
        }

        public void SetUploadParameter(string? processname)
        {
            var paramdetails = UploadParameterDetails.GetUploadParms().Where(x => x.ProcessName == processname).FirstOrDefault();
            ProcessField1 = Guid.NewGuid().ToString();
            ProcessField2 = paramdetails.ProcessField2;
            ProcessField3 = paramdetails.ProcessField3;
            ProcessField4 = paramdetails.ProcessField4;
            ProcessField5 = paramdetails.ProcessField5;
            ProcessField6 = paramdetails.ProcessField6;
            ProcessField7 = paramdetails.ProcessField7;
            ProcessField8 = paramdetails.ProcessField8;
            ProcessField9 = paramdetails.ProcessField9;
            ProcessField10 = paramdetails.ProcessField10;
        }
    }
}
