import { Injectable, Injector } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable()
export class AppConfigService 
{
  private appConfig:any;

  appInitializerFn = (appConfig: AppConfigService) => 
  {
    return () => {return appConfig.loadAppConfig();}
  };
  
  constructor (private injector: Injector) { }

  loadAppConfig()
  {
    let http = this.injector.get(HttpClient);
    return http.get('/assets/app-config.json')
    .subscribe(
      data => {this.appConfig = data;})
    }

    get config() {
        return this.appConfig;
    }
    
}
