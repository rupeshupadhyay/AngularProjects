import {
          HttpClient, HttpEvent, HttpEventType, HttpProgressEvent, HttpRequest,
          HttpResponse, HttpErrorResponse, HttpHeaders
        } from '@angular/common/http';
import { of } from 'rxjs';
import { Injectable } from '@angular/core';
import { environment } from '../../../environments/environment';

@Injectable({
  providedIn: 'root'
})
export class UploadexcelService 
{
  public fileExtension: any = "";
  public validfilextensions: string[] = [];
  public validextensionflg: boolean = false;
  apiUrl: string = environment.servicesBaseUrl;

  // Adding Dependencies of HttpClient & Message Service
  constructor(private http: HttpClient) { }

  validatefilextension() {
    // If extension found in list
    let found = this.validfilextensions.find((i) => i === this.fileExtension);
   if (found != undefined) { found.length > 0 ? this.validextensionflg = true : this.validextensionflg = false; }
  }

  uploaddata(files: any) {
    console.log('Upload proces started')
    if (files.length===0) { 
      console.log('No File Selected.')
      return; }
      
    let fileToUpload = <File>files[0];

    let formData = new FormData();  
    formData.append('file',fileToUpload,fileToUpload.name);
    
    console.log('API Calling Started');
    // Create the request object that POSTs the file to an upload endpoint.
    //const req = new HttpRequest('POST', "http://localhost:5148/api/ExcelDataProcess/UploadExcelData", formData, {headers:headers});
    
    //console.log('API Calling Returned');
    //return this.http.request(req).pipe(
     // map(event => this.getEventMessage(event, file)),
      //tap(message => this.showProgress(message)),
      //last(), // return last (completed) message to caller
      //catchError(this.handleError(file))
    //)
    console.log(this.apiUrl);
    this.http.post(this.apiUrl, formData, {reportProgress:true, observe: 'events'})
    .subscribe(
      {
        next:(event:any)=>{this.getEventMessage(event, fileToUpload)},
        error:(error:any)=>{this.handleError(fileToUpload)}
      }
    )
  }

  UploadExcel(formData: FormData) {  

    console.log(formData.get);

    let headers = new HttpHeaders();  
  
    headers.append('Content-Type', 'multipart/form-data');  
    headers.append('Accept', 'application/json');  
  
    const httpOptions = { headers: headers };  
  
    return this.http.post(this.apiUrl, formData, httpOptions)  
  } 

  handleError(file: any) {
    const userMessage = `${file.name} upload failed.`;
    return (error: HttpErrorResponse) => {
      console.error(error); // log to console instead
      const message = (error.error instanceof Error) ?
        error.error.message : `server returned code ${error.status} with body "${error.error}"`;
      console.log(`${userMessage} ${message}`);

      // Let app keep running but indicate failure.
      return of(userMessage);
    }
  }

  private showProgress(message: string) {
    console.log(message);
  }

  getEventMessage(event: HttpEvent<any>, file: File): any {
    switch (event.type) {
      case HttpEventType.Sent: return `Uploading file "${file.name}" of size ${file.size}.`;
      case HttpEventType.UploadProgress:// Compute and show the % done:
        const percentDone = Math.round(100 * event.loaded / (event.total ?? 0));
        return `File "${file.name}" is ${percentDone}% uploaded.`;
      case HttpEventType.Response:
        return `File "${file.name}" was completely uploaded!`;
      default: return `File "${file.name}" surprising upload event: ${event.type}.`;
    }
  }
}
