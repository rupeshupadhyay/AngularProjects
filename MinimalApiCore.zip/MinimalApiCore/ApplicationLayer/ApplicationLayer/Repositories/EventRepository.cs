﻿using ApplicationLayer.Contracts;
using ApplicationLayer.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;
using SQLDataAccess;
using ApplicationLayer.Dtos;

namespace ApplicationLayer.Repositories
{
    public class EventRepository : IEventRepository
    {
        private readonly ISqlDataHelper _db;

        public EventRepository(ISqlDataHelper db)
        {
            _db = db;
        }

        public Task AddNewEvent(EventDto ev) =>
        _db.SaveData("dbo.SPR_EVENT", new
        {
            P_Event_Id = 0,
            P_Event_Entity_Name = ev.EntityName,
            P_Pan_Card_Num = ev.PanCardNum,
            P_Job_Work_Order_Num = ev.JobWorkOrderNum,
            P_Event_Date = ev.EventDate,
            P_App_User_Id = 1,
            P_User_Name = ev.CreatedBy,
            P_Mode = "POST"
        });

        public Task DeleteEvent(int id) =>
        _db.SaveData("dbo.SPR_EVENT", new
        {
            P_Event_Id = id,
            P_Event_Entity_Name = "",
            P_Pan_Card_Num = "",
            P_Job_Work_Order_Num = "",
            P_Event_Date = "",
            P_App_User_Id = 1,
            P_User_Name = "",
            P_Mode = "DELETE"
        });

        public Task<IEnumerable<EventDto>> GetAllEvents() =>
            _db.GetData<EventDto, dynamic>("dbo.SPR_EVENT", new
            {
                P_Event_Id = 0,
                P_Event_Entity_Name = "",
                P_Pan_Card_Num = "",
                P_Job_Work_Order_Num = "",
                P_Event_Date = "",
                P_App_User_Id = 1,
                P_User_Name = "DEMO",
                P_Mode = "GETALL"
            });

        public  Task<IEnumerable<Annxure2>> GetAnnxure2(int id) =>
            _db.GetData<Annxure2, dynamic>("dbo.SPR_EVENT", new
            {
                P_Event_Id = id,
                P_Event_Entity_Name = "",
                P_Pan_Card_Num = "",
                P_Job_Work_Order_Num = "",
                P_Event_Date = "",
                P_App_User_Id = 1,
                P_User_Name = "DEMO",
                P_Mode = "GETDUPPAN"
            });

        public async Task<EventDto?> GetEvent(int id)
        {
            var results = await _db.GetData<EventDto, dynamic>( "dbo.SPR_EVENT", new 
            {
                P_Event_Id = id,
                P_Event_Entity_Name = "",
                P_Pan_Card_Num = "",
                P_Job_Work_Order_Num = "",
                P_Event_Date = "",
                P_App_User_Id = 1,
                P_User_Name = "DEMO",
                P_Mode = "GET"
            });

            return results.FirstOrDefault();
        }

        public Task UpdateEvent(EventDto ev) =>
        _db.SaveData("dbo.SPR_EVENT", new
        {
            P_Event_Id = ev.EventID,
            P_Event_Entity_Name = ev.EntityName,
            P_Pan_Card_Num = ev.PanCardNum,
            P_Job_Work_Order_Num = ev.JobWorkOrderNum,
            P_Event_Date = ev.EventDate,
            P_App_User_Id = 1,
            P_User_Name = ev.CreatedBy,
            P_Mode = "PUT"
        });
    }
}
