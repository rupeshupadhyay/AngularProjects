﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ApplicationLayer.Dtos
{
    public class Annexure7Dto
    {
        public string? Folder_ref { get; }
        public string? In_unitcd { get; }
        public string? In_inwno { get; }
        public string? Inwdate { get; }
        public string? In_subcd { get; }
        public string? Folio { get; }
        public string? Holder { get; }
        public string? Panno { get; }
        public string? Shares { get; }
        public string? Form_type { get; }
        public string? Valid_upto { get; }
        public string? Country { get; }
        public string? Tax_idno { get; }
        public string? Dob { get; }
        public string? Assesment_year { get; }
        public string? Form_status { get; }
        public string? Trandate { get; }
        public string? Clientstatus { get; }
        public string? Client_remarks { get; }
        public string? Clientconfdate { get; }
        public string? Hold_minor { get; }
        public string? Category { get; }
        public string? Obj_code { get; }
        public string? Accept_reject { get; }
        public string? Reasons { get; }
        public string? Tds_rate_per { get; }
    }
}
