import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { Annexure4Dto } from '../annexure4-dto';
import { Annexure8Dto } from '../annexure8-dto';
import { Annexure9Dto } from '../annexure9-dto';
import { Annexure10Dto } from '../annexure10-dto';
import { Annexure11Dto } from '../annexure11-dto';
import { DupPanDto} from '../dup-pan-dto'
import { EventService } from '../event.service';

@Component
(
  {
    selector: 'app-event-upload',
    templateUrl: './event-upload.component.html'
  }
)
export class EventUploadComponent implements OnInit 
{
  
  duppandtos:DupPanDto[]=[];
  eventID:string="0"; 
  entityName:string="";
  eventDate:string="";
  blntDupPanApplyHeaderStyle:boolean=true;
  exportDupPanHeaders:string []=["bfitpan","dpid", "holderfolio", "holder"];
  exportDupLineItems:[]=[];
  uploadStatus:string="";

  // Annexure4 Report Details
  annexure4Dto:Annexure4Dto[]=[];
  exportannexure4Headers:string []=['DPID','HOLDER_FOLIO','DPID_FOLIO','BFITPAN','RESIDENTIAL','CURRENTDIVIDEND','OLDDIVIDEND','IEPFCURRENTDIVIDEND','IEPFOLDDIVIDEND','TOTALDIVIDEND','TYPEOFSHAREHOLDER','PANVERIFICATION','SECTION206AB','PANSTATUS','THRESHOLDBENEFIT','DUALRESIDENTSTATUS','PANAGGREATION'];
  blntannexure4HeaderStyle:boolean=true;
  exportannexure4LineItems:[]=[];
 
  // Annexure8 Report Details
  annexure8Dto:Annexure8Dto[]=[];
  exportannexure8Headers:string []=['BFITPAN','DPID','HOLDER_FOLIO','HOLDER','SECOND','THIRD','HOLDER_ADDR1','HOLDER_ADDR2','HOLDER_ADDR3','HOLDER_ADDR4','HOLDER_PIN','BANK_ACCNO','BANK_NAME','BANK_ADDR1','BANK_ADDR2','BANK_ADDR3','BANK_ADDR4','BANK_PIN','IFSC_CODE','ECS_MICR','ECS_ACTYPE','ECS_ACNO','BFITPAN2','ISIN_CODE','HOLD_MINOR','STATUS_DESC','PUL_CODE','TOTAL_SHAR','GROSS_AMT','TDSAMT','NET_AMOUNT','TAX_PER','COUNTRY_CODE','COUNTRY_NAME','BANK','WAR_MODE','WARRANTNO','TYPE','BENPOS_DATE','WARDATE','WAR_ACNO','OLD_GROSS','OLD_TDS','CURRENTDIVIDEND','OLDDIVIDEND','TOTAL_DIVIDEND_PAID','RESIDENTIAL_STATUS','PAN VERIFICATION','SPECIFIED_PERSON_SEC_206AB','SHAREHOLDER_CATEGORY','THRESHHOLD_BENEFIT_ALLOWED','ACCEPT_REJECT','REASONS','TDS_RATE','BASE_TDS_RATE','SURCHARGE','EDUCATION_CESS','EFFECTIVE_TDS_RATE','TDS_AMOUNT','NET AMOUNT','FORM_15CA_CB_COMPLIANCE'];
  blntannexure8HeaderStyle:boolean=true;
  exportannexure8LineItems:[]=[];

  // Annexure9 Report Details
  annexure9Dto:Annexure9Dto[]=[];
  exportannexure9Headers:string []=['DPID','HOLDER_FOLIO','HOLDER','SECOND','THIRD','HOLDER_ADDR1','HOLDER_ADDR2','HOLDER_ADDR3','HOLDER_ADDR4','HOLDER_PIN','BANK_ACCNO','BANK_NAME','BANK_ADDR1','BANK_ADDR2','BANK_ADDR3','BANK_ADDR4','BANK_PIN','IFSC_CODE','ECS_MICR','ECS_ACTYPE','ECS_ACNO','BFITPAN2','ISIN_CODE','HOLD_MINOR','STATUS_DESC','PUL_CODE','TOTAL_SHAR','GROSS_AMT','TDSAMT','NET_AMOUNT','TAX_PER','COUNTRY_CODE','COUNTRY_NAME','BANK','WAR_MODE','WARRANTNO','TYPE','BENPOS_DATE','WARDATE','WAR_ACNO','OLD_GROSS','OLD_TDS'];
  blntannexure9HeaderStyle:boolean=true;
  exportannexure9LineItems:[]=[];

  // Annexure10 Report Details
  annexure10Dto:Annexure10Dto[]=[];
  exportannexure10Headers:string []=['DPID','HOLDER_FOLIO','HOLDER','SECOND','THIRD','HOLDER_ADDR1','HOLDER_ADDR2','HOLDER_ADDR3','HOLDER_ADDR4','HOLDER_PIN','BANK_ACCNO','BANK_NAME','BANK_ADDR1','BANK_ADDR2','BANK_ADDR3','BANK_ADDR4','BANK_PIN','IFSC_CODE','ECS_MICR','ECS_ACTYPE','ECS_ACNO','BFITPAN2','ISIN_CODE','HOLD_MINOR','STATUS_DESC','PUL_CODE','TOTAL_SHAR','GROSS_AMT','TDSAMT','NET_AMOUNT','TAX_PER','COUNTRY_CODE','COUNTRY_NAME','BANK','WAR_MODE','WARRANTNO','TYPE','BENPOS_DATE','WARDATE','WAR_ACNO','OLD_GROSS','OLD_TDS'];
  blntannexure10HeaderStyle:boolean=true;
  exportannexure10LineItems:[]=[];

  // Annexure11 Report Details
  annexure11Dto:Annexure11Dto[]=[];
  exportannexure11Headers:string []=['DPID','HOLDER_FOLIO','HOLDER','SECOND','THIRD','HOLDER_ADDR1','HOLDER_ADDR2','HOLDER_ADDR3','HOLDER_ADDR4','HOLDER_PIN','BANK_ACCNO','BANK_NAME','BANK_ADDR1','BANK_ADDR2','BANK_ADDR3','BANK_ADDR4','BANK_PIN','IFSC_CODE','ECS_MICR','ECS_ACTYPE','ECS_ACNO','BFITPAN2','ISIN_CODE','HOLD_MINOR','STATUS_DESC','PUL_CODE','TOTAL_SHAR','GROSS_AMT','TDSAMT','NET_AMOUNT','TAX_PER','COUNTRY_CODE','COUNTRY_NAME','BANK','WAR_MODE','WARRANTNO','TYPE','BENPOS_DATE','WARDATE','WAR_ACNO','OLD_GROSS','OLD_TDS','TDS_RATE','EFFECTIVE_TDS_RATE'];
  blntannexure11HeaderStyle:boolean=true;
  exportannexure11LineItems:[]=[];

  constructor(private eventsvc:EventService,private route:ActivatedRoute,private router:Router) { }

  ngOnInit(): void 
  {  
    this.eventID=sessionStorage['app.eventid']
    this.entityName=sessionStorage['app.entitynm'];
    this.eventDate=sessionStorage['app.eventdate'];
    this.LoadDupData();
    this.LoadAnnexure9Data();
    this.LoadAnnexure10Data();
    this.LoadAnnexure11Data();
  }

  LoadDupData()
  {
     //Implementing Subscriber
     this.eventsvc.getDupPanList(this.eventID)
     .subscribe(
                  (response: DupPanDto[]) => {this.duppandtos = response;}
                );
  }

  LoadAnnexure4Data()
  { 
    //Implementing Subscriber
    this.eventsvc.getAnnexure4List(this.eventID)
    .subscribe(
                 (response: Annexure4Dto[]) => {this.annexure4Dto = response;}
               );

  }

  LoadAnnexure8Data()
  { 
    //Implementing Subscriber
    this.eventsvc.getAnnexure8List(this.eventID)
    .subscribe(
                 (response: Annexure8Dto[]) => {this.annexure8Dto = response;}
               );

  }

  LoadAnnexure9Data()
  { 
    //Implementing Subscriber
    this.eventsvc.getAnnexure9List(this.eventID)
    .subscribe(
                 (response: Annexure9Dto[]) => {this.annexure9Dto = response;}
               );

  }

  LoadAnnexure10Data()
  { 
    //Implementing Subscriber
    this.eventsvc.getAnnexure10List(this.eventID)
    .subscribe(
                 (response: Annexure10Dto[]) => {this.annexure10Dto = response;}
               );

  }

  LoadAnnexure11Data()
  { 
    //Implementing Subscriber
    this.eventsvc.getAnnexure11List(this.eventID)
    .subscribe(
                 (response: Annexure11Dto[]) => {this.annexure11Dto = response;}
               );

  }

  // Called From Upload Child Component
  RefreshData(event:any)
  {
    console.log(event);

    let ProcessId = event.Id;
    let Message = event.Message;
    
    switch(ProcessId)
    {
      //case 'objAnnexure14': alert(Message);
                            //this.LoadDupData();
      //                      return;
      /*case 'objAnnexure1':  alert(Message);
                            //this.LoadDupData();
                            return;
      case 'objAnnexure5':  alert(Message);
                            //this.LoadDupData();
                            return;
      */
      /*case 'objAnnexure13': alert(Message);
                            //this.LoadDupData();
                            return;*/
      default:  alert(Message);
                return;
    }

    this.LoadDupData();
    this.LoadAnnexure9Data();
    this.LoadAnnexure10Data();
    this.LoadAnnexure11Data();
  }
}
