import { Injectable } from '@angular/core';
import {HttpClient, HttpHeaders} from '@angular/common/http'; // Http Client 
import { Observable } from 'rxjs'; // Subscription Metod 
import {EventDto} from './event-dto'; // Model Class Dto for Data Transfer Activities.
import {DupPanDto} from './dup-pan-dto'; 
import { ExcelDataProcessDto } from './excel-data-process-dto';
import { AppConfigService } from '../../../services/common/app-config.service';

@Injectable()
export class EventService {

  headers = new HttpHeaders({ 'Content-Type': 'application/json' });
  baseUrl:string;

  //HttpClient Injection
  constructor(private httpclient:HttpClient,private appSvc:AppConfigService) 
  { 
    this.baseUrl= appSvc.appApiUrl;
  }

  // Get All Events
  getEventList(): Observable<EventDto[]>
  {
    //Get Command
    return this.httpclient.get<EventDto[]>(this.baseUrl+'/Event');
  }

  // Get Selected Event by Event ID
  getEventListID(eventid:string): Observable<EventDto>
  {
    //Get Command
    return this.httpclient.get<EventDto>(this.baseUrl+'/Event/'+eventid);
  }

  // Get Duplicate Pan Data
  getDupPanList(eventid:string): Observable<DupPanDto[]>
  {
    //Get Command
    return this.httpclient.get<DupPanDto[]>(this.baseUrl+'/Event/1'+''+'/DupPan');
  }
  
  // Post New Event Data
  postEventdata(eventdto:EventDto): Observable<EventDto>
  {
    console.log(EventDto);

    
    //let body = JSON.stringify(EventDto); 

   // console.log(body); 
    console.log(this.headers);
    //Post Command
    return this.httpclient.post<EventDto>(this.baseUrl+'/Event',eventdto,{headers:this.headers});
  }

  // Update Event Data
  putEventdata(eventdto:EventDto): Observable<any>
  {
    return this.httpclient.put<EventDto>(this.baseUrl+'/Event',eventdto,{headers:this.headers});
  }

  // Delete Event Data
  deleteEventdata(eventid:string): Observable<any>
  {
    return this.httpclient.delete(this.baseUrl+'/Event/'+eventid,{headers:this.headers});
  }

  // Process Excel Data
  postExceldata(exceldataprocessdto:ExcelDataProcessDto): Observable<string>
  {
    console.log(exceldataprocessdto);
    console.log(this.headers);
    console.log(this.baseUrl+'/Event/Id');
    //Post Command
    return this.httpclient.post<string>(this.baseUrl+'/Event/Id',exceldataprocessdto,{headers:this.headers});
  }

}
