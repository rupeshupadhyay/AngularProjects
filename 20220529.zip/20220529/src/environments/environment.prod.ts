export const environment = {
  production: true,
  servicesBaseUrl:'http://localhost:5147/api'
};
