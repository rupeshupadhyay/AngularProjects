export class Annexure6Dto 
{
    s_no:string;
    pan:string;
    name:string;
    pan_allotment_date:string;
    pan_aadhaar_link_status:string;
    specified_person_206ab_206cca:string;
    created_date:string;
    
    constructor()
    {
        this.s_no='';
        this.pan='';
        this.name='';
        this.pan_allotment_date='';
        this.pan_aadhaar_link_status='';
        this.specified_person_206ab_206cca='';
        this.created_date='';

    }
}
