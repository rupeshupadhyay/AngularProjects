import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute} from '@angular/router';
import { EventDto } from '../event-dto';
import { EventService } from '../event.service';

@Component
({
  selector: 'app-event-edit',
  templateUrl: './event-edit.component.html'
})
export class EventEditComponent implements OnInit 
{
  eventID: string = "";
  entityName: string = "";
  panCardNum: string = "";
  jobWorkOrderNum: string = "";
  eventDate: string = "";

  eventdtos: EventDto[] = [];
  objEditEvent: EventDto = new EventDto();

  constructor(private eventsvc: EventService, private route: ActivatedRoute, private router: Router) 
  {
    this.objEditEvent.entityName = "";
    this.objEditEvent.panCardNum = "";
    this.objEditEvent.jobWorkOrderNum = "";
    this.objEditEvent.eventDate = "";
    this.objEditEvent.createdBy = "";
    this.objEditEvent.eventID = 0;
    this.objEditEvent.lastModifiedBy = "";
    this.objEditEvent.lastModifiedDate = "";
  }

  ngOnInit(): void 
  {
    this.eventID = sessionStorage['app.eventid'];
    sessionStorage.removeItem('app.eventid');
    
    this.eventsvc.getEventListID(this.eventID.toString())
    .subscribe
    (
      (response: EventDto) => 
      {
        this.objEditEvent = response;
        this.objEditEvent.eventDate=this.objEditEvent.eventDate.split("/").reverse().join("-").slice(0, 10);
        console.log(this.objEditEvent.eventDate);
      },
      (error:any)=>{console.log(error)},
      ()=>{this.LoadEventData();}
    );
  }

  LoadEventData() 
  {
    console.log('Edited Event ID : ' + this.eventID.toString())
    console.log('Edited Event Date : ' +this.objEditEvent.eventDate);
    console.log(this.eventdtos);
  }

  onSaveClick() 
  {
    console.log(this.objEditEvent);

    this.eventsvc.putEventdata(this.objEditEvent)
    .subscribe
    (
        (response?: EventDto) => 
        {
          //Add Project to Grid
          console.log(response);
          // After updating data move to event list page
          this.router.navigateByUrl('\events', {replaceUrl: true});
        },
        (error: any) => {console.log(error);},
        ()=>{console.log('Data Update Completed.')}
    );
  }

  onUploadClick(event:Event) 
  {
    //event.preventDefault();
    sessionStorage['app.eventid']=this.eventID;
    sessionStorage['app.entitynm']=this.objEditEvent.entityName;
    sessionStorage['app.eventdate']=this.objEditEvent.eventDate;
    this.router.navigateByUrl('/uploadE', {replaceUrl: true});
  }

  onCancelClick(event:Event)
  {
    //event.preventDefault();
    this.router.navigateByUrl('\events', {replaceUrl: true});
  }
}
