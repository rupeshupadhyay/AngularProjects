import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { DupPanDto} from '../dup-pan-dto'
import { EventService } from '../event.service';

@Component
(
  {
    selector: 'app-event-upload',
    templateUrl: './event-upload.component.html'
  }
)
export class EventUploadComponent implements OnInit 
{
  
  duppandtos:DupPanDto[]=[];
  eventID:string="0"; 
  entityName:string="";
  eventDate:string="";
  blntDupPanApplyHeaderStyle:boolean=true;
  exportDupPanHeaders:string []=["bfitpan","dpid", "holderfolio", "holder"];
  exportDupLineItems:[]=[];
  uploadStatus:string="";
    
  constructor(private eventsvc:EventService,private route:ActivatedRoute,private router:Router) { }

  ngOnInit(): void 
  {  
    this.eventID=sessionStorage['app.eventid']
    this.entityName=sessionStorage['app.entitynm'];
    this.eventDate=sessionStorage['app.eventdate'];
    this.LoadDupData();
  }

  LoadDupData()
  {
     //Implementing Subscriber
     this.eventsvc.getDupPanList(this.eventID)
     .subscribe(
                  (response: DupPanDto[]) => {this.duppandtos = response;}
                );
  }

  // Called From Upload Child Component
  RefreshData(event:any)
  {
    console.log(event);

    let ProcessId = event.Id;
    let Message = event.Message;
    
    switch(ProcessId)
    {
      case 'objAnnexure14': alert(Message);
                            this.LoadDupData();
                            return;
      /*case 'objAnnexure1':  alert(Message);
                            //this.LoadDupData();
                            return;
      case 'objAnnexure5':  alert(Message);
                            //this.LoadDupData();
                            return;
      */
      case 'objAnnexure13': alert(Message);
                            this.LoadDupData();
                            return;
      default:  alert(Message);
                return;
    }
  }
}
