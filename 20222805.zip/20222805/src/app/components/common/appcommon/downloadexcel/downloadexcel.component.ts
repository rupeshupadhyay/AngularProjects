import { Component, Input, OnInit } from '@angular/core';
import { DownloadexcelService } from 'src/app/services/export/downloadexcel.service';

@Component({
  selector: 'app-downloadexcel',
  templateUrl: './downloadexcel.component.html'
})

export class DownloadexcelComponent implements OnInit 
{
  // Download Component ObjectID
  @Input() Id:string="objDownload";
  // Caption for Download Button
  @Input() strDownloadcaption:string="Download";
  // Excel Output File Prefix
  @Input() strExportFilePrefix:string="Test";
  // Worksheet Name
  @Input() strWorkSheetNm:string="Details";
  //Excel Header Details
  @Input() headers:any[]=[];
  //Excel Line Item Details
  @Input() lineItemDto:any;
  //Where to apply style in Header or Not 
  @Input() ShowHeaderStyle:boolean=true;

  // Download Service Injection
  constructor(private downloadexcelsvc:DownloadexcelService) { }

  ngOnInit(): void {}

  // Download Excel Report Function
  DownloadExcelReport()
  {
    // assign the input data setup in parent component 
    this.downloadexcelsvc.filenm=this.strExportFilePrefix;
    this.downloadexcelsvc.worksheetnm=this.strWorkSheetNm;
    this.downloadexcelsvc.headerdata= this.headers;
    this.downloadexcelsvc.showheaderestyleflg=this.ShowHeaderStyle;
    this.downloadexcelsvc.lineItemDto=this.lineItemDto;
    this.downloadexcelsvc.ExportToExcel();
  }
}
