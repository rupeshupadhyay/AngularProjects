﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ApplicationLayer.Dtos
{
    public class Annexure3Dto
    {
        public string? Dp_id { get; }
        public string? Holder_folio { get; }
        public string? Dp_id_n_holder_folio { get; }
        public string? Pan { get; }
    }
}
