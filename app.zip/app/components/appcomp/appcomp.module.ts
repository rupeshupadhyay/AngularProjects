import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { EventComponent } from './event/event.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { AppcommonModule } from '../common/appcommon/appcommon.module';
import { EventService } from './event/event.service';
import { EventEditComponent } from './event/event-edit/event-edit.component';
import { EventCreateComponent } from './event/event-create/event-create.component';
import { EventUploadComponent } from './event/event-upload/event-upload.component';
//Application Component Module  
@NgModule({
  declarations: [EventComponent, EventEditComponent, EventCreateComponent, EventUploadComponent],
  providers:[
      EventService
    ],
  imports: [
    CommonModule,
    FormsModule, ReactiveFormsModule,
    AppcommonModule
  ],
  exports:[
    EventComponent, EventEditComponent, EventCreateComponent, EventUploadComponent
  ]
})
export class AppcompModule { }
