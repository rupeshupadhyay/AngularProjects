import { Component, Input, OnInit } from '@angular/core';
import { DownloadexcelService } from 'src/app/services/export/downloadexcel.service';

@Component({
  selector: 'app-downloadexcel',
  templateUrl: './downloadexcel.component.html'
})
export class DownloadexcelComponent implements OnInit {

  // Get Input from implemented component
  @Input() strDownloadcaption:string="Download";
  @Input() strExportFilePrefix:string="Test";
  @Input() strWorkSheetNm:string="Details";
  @Input() headers:any[]=[];
  @Input() lineitems:any[]=[];

  constructor(private downloadexcelsvc:DownloadexcelService) { }

  ngOnInit(): void {
  }

  DownloadExcelReport()
  {
    // assign the input data setup in parent component 
    this.downloadexcelsvc.filenm=this.strExportFilePrefix;
    this.downloadexcelsvc.worksheetnm=this.strWorkSheetNm;
    this.downloadexcelsvc.headerdata= this.headers;
    this.downloadexcelsvc.lineitems=this.lineitems;
    this.downloadexcelsvc.ExportExcel();
  }

}
