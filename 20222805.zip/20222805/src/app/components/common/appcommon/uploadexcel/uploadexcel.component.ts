import { Component, Input, OnInit, Output , EventEmitter} from '@angular/core';
import {HttpClient, HttpEvent, HttpEventType, HttpErrorResponse} from '@angular/common/http';
import { EventService } from 'src/app/components/appcomp/event/event.service';
import { ExcelDataProcessDto } from 'src/app/components/appcomp/event/excel-data-process-dto';

@Component({
  selector: 'app-uploadexcel',
  templateUrl: './uploadexcel.component.html'
})

export class UploadexcelComponent implements OnInit {

  // Component ID 
  @Input() ID:string="objUpload";
  // Caption for Component  
  @Input() UploadCaption:string="Demo";
  // Process Parameter to pick the source & destination service
  @Input() ProcessId:string="0";
  // Custom Field to Process Data 
  @Input() CustomField:string="";
  // Parameter to Call Parent Function for any Data Handling. 
  @Output('RefreshData') RefreshData: EventEmitter<any> = new EventEmitter();
  
  // Progress Parameter flag
  showLoading:boolean=false;
  fileExtension: any = "";
  validfilextensions: string[] = [];
  validextensionflg: boolean = false;
  // Api Url
  apiUrl: string = "http://localhost:5148/api/ExcelDataProcess/Upload";
  message:string="";
  exceldataprocessdto:ExcelDataProcessDto = new ExcelDataProcessDto();

  // Adding Dependencies of HttpClient 
  constructor(private http: HttpClient,private eventsvc:EventService) { }

  ngOnInit(): void {}

  validatefilextension() 
  {
    // If extension found in list
    let found = this.validfilextensions.find((i) => i === this.fileExtension);
    if (found != undefined) { found.length > 0 ? this.validextensionflg = true : this.validextensionflg = false; }
  }

  uploaddata(files: any)  
  {
    //Show Processing 
    this.showLoading=true;

    console.log('uploaddata :'+'Upload proces started.');

    if (files.length===0) 
    { 
      console.log('No File Selected.');
      return ; 
    }
      
    let fileToUpload = <File>files[0];
    let formData = new FormData();  
    formData.append('file',fileToUpload,fileToUpload.name);
    
    console.log('uploaddata :'+'API Call Inititated')
    
    return this.http.post(this.apiUrl + '/' + this.ProcessId, formData,{reportProgress:true,responseType:"text"})
            .subscribe(
            {
              next:(res:any)=>
              {
                console.log('uploaddata (Next) :'+'Event Calling('+res+')');
                this.getEventMessage(res, fileToUpload)   
                // Get the Guid and Call the Data Process API to Process Temp Data        
                this.exceldataprocessdto.eventID= this.CustomField;
                this.exceldataprocessdto.uploadGuid=res;
                this.exceldataprocessdto.userName = "DEMOUSER";
                
                // After Posting Call upload serive to process data
                this.eventsvc.postExceldata(this.exceldataprocessdto).subscribe
                (
                  (response?: string) => 
                  {
                    this.showLoading=false;
                    this.RefreshData.emit({"Id":this.ID,"Message":"Data Uploaded Sucessfully."});
                  },
                  (error:any) => 
                  {
                    this.showLoading=false;
                    console.log(error);
                    this.RefreshData.emit({"Id":this.ID,"Message":`Data Processing Failed,Error${error.error}`});
                  }
                );
              },
              error:(err:HttpErrorResponse)=>
              {
                this.showLoading=false;
                console.log(err.error);
                this.message=err.error;
                this.RefreshData.emit({"Id":this.ID,"Message":`Data Processing Failed,API Error:${err.message}`});
              },
              complete:()=>
              {
                this.showLoading=false;
                console.log('uploaddata (Complete) :'+'File Upload process completed.');
                this.message='';
                }
            }
          )
  }

  getEventMessage(event: HttpEvent<any>, file: File): any 
  {
    switch (event.type) 
    {
      case HttpEventType.Sent:
        this.message = `Uploading file "${file.name}" of size ${file.size}.`;
        console.log('Event Sent :'+this.message);
        return this.message;
      case HttpEventType.UploadProgress:// Compute and show the % done:
        const percentDone = Math.round(100 * event.loaded / (event.total ?? 0));
        this.message= `File "${file.name}" is ${percentDone}% uploaded.`;
        console.log('Event Upload Progress :'+this.message);
        return this.message;
      case HttpEventType.Response:
        console.log(event.type);
        this.message= `File "${file.name}" was completely uploaded!`;
        console.log('Event Response :'+this.message);
        console.log('Event Body :'+ event.body);
        return this.message;
    }
  }

}
