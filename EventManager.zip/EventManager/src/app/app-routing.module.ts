import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { DashboardComponent } from './admin/dashboard/dashboard.component';
import { AboutComponent } from './admin/about/about.component';
import { EventManagerComponent } from './event-mgmt/event-manager/event-manager.component';
import { ProjectsComponent } from './admin/projects/projects.component';
import { EventComponent } from './event-mgmt/event/event.component';

const routes: Routes = [
  { path: 'dashboard', component:DashboardComponent },
  { path: 'about', component: AboutComponent },
  { path:'manager',component: EventManagerComponent},
  { path:'events',component: EventComponent},
  { path:'projects',component: ProjectsComponent},
  { path: '', redirectTo: 'events', pathMatch: 'full' },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule],
})
export class AppRoutingModule {}
