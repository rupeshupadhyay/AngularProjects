import { Injectable } from '@angular/core';
import {HttpClient, HttpHeaders} from '@angular/common/http'; // Http Client 
import { Observable } from 'rxjs'; // Subscription Metod 
import {EventDto} from './event-dto'; // Model Class Dto for Data Transfer Activities.
import {DupPanDto} from './dup-pan-dto'; 
import { AppConfigService } from '../../../services/common/app-config.service';

@Injectable()
export class EventService {

  headers = new HttpHeaders({ 'Content-Type': 'application/json' });
  baseUrl:string='http://localhost:5002/api';

  //HttpClient Injection
  constructor(private httpclient:HttpClient) { 
    //this.baseUrl= this.environment.config.servicesBasePath;

  }

  getEventList(): Observable<EventDto[]>
  {
    //Get Command
    return this.httpclient.get<EventDto[]>(this.baseUrl+'/Event');
  }

  getEventListID(eventid:string): Observable<EventDto>
  {
    //Get Command
    return this.httpclient.get<EventDto>(this.baseUrl+'/Event/'+eventid);
  }

  getDupPanList(eventid:string): Observable<DupPanDto[]>
  {
    //Get Command
    return this.httpclient.get<DupPanDto[]>(this.baseUrl+'/Event/1'+''+'/DupPan');
  }
  

  

  postEventdata(eventdto:EventDto): Observable<EventDto>
  {
    console.log(EventDto);

    
    //let body = JSON.stringify(EventDto); 

   // console.log(body); 
    console.log(this.headers);
    //Post Command
    return this.httpclient.post<EventDto>(this.baseUrl+'/Event',eventdto,{headers:this.headers});
  }

  putEventdata(eventdto:EventDto): Observable<any>
  {
    return this.httpclient.put<EventDto>(this.baseUrl+'/Event',eventdto,{headers:this.headers});
  }

  deleteEventdata(eventid:string): Observable<any>
  {
    return this.httpclient.delete(this.baseUrl+'/Event/'+eventid,{headers:this.headers});
  }
}
