import { HttpClient,HttpHeaders } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute, ParamMap } from '@angular/router';
import { EventDto } from '../event-dto';
import { EventSvcService } from '../event-svc.service';
import { FormGroup, FormBuilder, FormControl, Validators } from '@angular/forms';

@Component({
  selector: 'app-event',
  templateUrl: './event.component.html',
  styleUrls: ['./event.component.scss']
})
export class EventComponent implements OnInit {

  eventdtos:EventDto[]=[];
  objNewEvent:EventDto = new EventDto();

  //var httpOptions = {headers: new HttpHeaders({'Content-Type':  'application/json'}) };

  constructor(private eventsvc:EventSvcService,private route:ActivatedRoute,private router:Router) { }

  
  ngOnInit(): void {
    //Implementing Subscriber
    this.eventsvc.getEventList().subscribe(
      (response: EventDto[]) => {
        this.eventdtos = response;
      }
    );

    
  }
  

  onSaveClick() {
    //(method) Observable<EventDto>.subscribe(next?: ((value: EventDto) => void) | null | undefined, error?: ((error: any) => void) | null | undefined, complete?: (() => void) | null | undefined): Subscription (+2 overloads)
    console.log(this.objNewEvent);
    this.route.queryParams.subscribe(params=>
      {
        this.objNewEvent.entityName  = params["entityName"];
      });
    this.eventsvc.postEventdata(this.objNewEvent).subscribe(
      (response?: EventDto) => {
        //Add Project to Grid
        console.log(response);
                
        //Clear New Project Dialog - TextBoxes
        //this.objNewEvent.entityName = "";
        //this.objNewEvent.jobWorkOrderNum = "";
        //this.objNewEvent.panCardNum = "";
        //this.objNewEvent.eventDate = "";

      },
     (error:any) => {console.log(error);}
      );

     this.gotoManage();

  }

  gotoManage()
  {
    this.router.navigate(['manager']);
  }

}
