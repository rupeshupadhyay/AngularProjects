import { Component, OnInit } from '@angular/core';
import {DupPanDto} from '../dup-pan-dto'
import { EventService } from '../event.service';
import { Router, ActivatedRoute, ParamMap } from '@angular/router';

@Component({
  selector: 'app-event-upload',
  templateUrl: './event-upload.component.html'
})
export class EventUploadComponent implements OnInit {
  duppandtos:DupPanDto[]=[];
  eventID:string="0";
  entityName:string="";
  eventDate:string="";
  exportDupPanHeaders:string []=["bfitpan","dpid", "holderfolio", "holder"];
  exportDupLineItems:[]=[];
  
  constructor(private eventsvc:EventService,private route:ActivatedRoute,private router:Router) { }

  ngOnInit(): void 
  {  
    this.eventID=sessionStorage['app.eventid']
    this.entityName=sessionStorage['app.entitynm'];
    this.eventDate=sessionStorage['app.eventdate'];
    this.LoadDupData();
  }

  LoadDupData()
  {
     //Implementing Subscriber
     this.eventsvc.getDupPanList(this.eventID).subscribe(
      (response: DupPanDto[]) => {
        this.duppandtos = response;
        console.log(this.duppandtos);
        //Coverting Event Json in Array of Array
        this.exportDupLineItems=this.convertDtoinArray(this.duppandtos);
      }
    );
  }

  convertDtoinArray(objinput:any):any
  {
    var objOutPut=[];
    for(var i=0;i<objinput.length;i++)
    {
      const ele=objinput[i];
      objOutPut.push(Object.values(ele));
    }
    return objOutPut;
  }



}
